<?php
session_start();
if (!empty($_SESSION['access_token']) && in_array($_SESSION['role'] ?? '', ['admin','organiser','customer'], true)) {
    header('Location: dashboards/' . $_SESSION['role'] . '.php'); exit;
}
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
        $error = 'Invalid form session. Refresh and try again.';
    } else {
        $email = trim((string)($_POST['email'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
            $error = 'Please enter a valid email and password.';
        } else {
            $url = 'http://127.0.0.1/event_ticketing_api/api/login.php';
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode(['email'=>$email,'password'=>$password]),
                CURLOPT_HTTPHEADER => ['Content-Type: application/json','Accept: application/json'],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 12,
                CURLOPT_CONNECTTIMEOUT => 4,
            ]);
            $result = curl_exec($ch);
            $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);
            $data = is_string($result) ? json_decode($result, true) : null;
            $role = $data['user']['role'] ?? '';
            if ($http === 200 && ($data['success'] ?? false) === true && is_string($data['access_token'] ?? null) && in_array($role, ['admin','organiser','customer'], true)) {
                session_regenerate_id(true);
                $_SESSION['access_token'] = $data['access_token'];
                $_SESSION['role'] = $role;
                $_SESSION['user_id'] = (int)($data['user']['user_id'] ?? 0);
                $_SESSION['full_name'] = (string)($data['user']['full_name'] ?? 'User');
                header('Location: dashboards/' . $role . '.php'); exit;
            }
            $error = $curlError ? 'Cannot reach login API. Check XAMPP and PHP cURL.' : ($http === 401 ? 'Incorrect email or password.' : 'Login failed. Check your API and try again.');
        }
    }
}
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Log In | EventTix</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="login-page">
<main class="split">
<section class="hero">
  <div class="hero-overlay"></div>
  <div class="hero-content">
    <a class="brand brand-light" href="index.php"><span class="brand-icon">✦</span> EVENT<span>TIX</span></a>
    <div class="hero-main"><div class="eyebrow">BRINGING PEOPLE TOGETHER <span></span></div>
      <h1>Event Ticketing and <em>Venue Booking</em> System</h1>
      <p class="hero-desc">Discover amazing events, find great venues and create unforgettable experiences.</p>
      <div class="features">
        <div class="feature"><span class="feature-icon purple">✦</span><div><strong>Various Events</strong><small>Conferences, concerts, exhibitions and more.</small></div></div>
        <div class="feature"><span class="feature-icon pink">▦</span><div><strong>Premium Venues</strong><small>Find the perfect place for your next event.</small></div></div>
        <div class="feature"><span class="feature-icon green">✓</span><div><strong>Easy & Secure Booking</strong><small>Fast, simple and protected booking.</small></div></div>
      </div>
    </div>
    <div class="hero-footer"><span>✧ &nbsp; Discover</span><span>⌖ &nbsp; Book</span><span>♡ &nbsp; Experience</span></div>
  </div>
</section>
<section class="login-side">
  <nav class="top-nav"><a href="index.php">Home</a><span class="nav-pill">EventTix Portal</span></nav>
  <div class="login-card">
    <div class="ticket-logo">◇</div><h2>Welcome Back</h2><p class="subheading">Log in to your account to continue to EventTix</p>
    <?php if ($error): ?><div class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <form method="post" action="login.php">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
      <label for="email">Email Address</label><div class="input-wrap"><span>✉</span><input id="email" name="email" type="email" placeholder="Enter your email" autocomplete="username" required value="<?= htmlspecialchars((string)($_POST['email'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"></div>
      <div class="password-heading"><label for="password">Password</label></div>
      <div class="input-wrap"><span>♙</span><input id="password" name="password" type="password" placeholder="Enter your password" autocomplete="current-password" required><button class="eye" type="button" id="togglePassword" aria-label="Show password">◉</button></div>
      <button class="login-button" type="submit">Log In <span>→</span></button>
    </form>
    <div class="divider"><span>ACCESS FOR</span></div>
    <div class="roles"><div class="role admin"><span>♜</span><strong>Admin</strong><small>Manage platform</small></div><div class="role organiser"><span>▦</span><strong>Organiser</strong><small>Manage events</small></div><div class="role customer"><span>♧</span><strong>Customer</strong><small>Book tickets</small></div></div>
    <p class="footnote">Need an account? <span>Contact the administrator.</span></p>
  </div>
  <p class="copyright">© <?= date('Y') ?> EventTix. All rights reserved.</p>
</section>
</main>
<script>const toggle=document.getElementById('togglePassword'),password=document.getElementById('password');toggle.addEventListener('click',()=>{password.type=password.type==='password'?'text':'password';toggle.setAttribute('aria-label',password.type==='password'?'Show password':'Hide password');});</script>
</body></html>
