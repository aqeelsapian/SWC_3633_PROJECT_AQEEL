<?php
$requiredRole = 'customer';
require __DIR__ . '/../includes/auth_guard.php';
$token = (string)$_SESSION['access_token'];
$name = htmlspecialchars((string)($_SESSION['full_name'] ?? 'Customer'), ENT_QUOTES, 'UTF-8');
if (empty($_SESSION['customer_booking_csrf'])) $_SESSION['customer_booking_csrf'] = bin2hex(random_bytes(24));
function cbEsc($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function cbApi(string $endpoint, string $token, string $method='GET', ?array $body=null): array {
    $ch=curl_init('http://localhost/event_ticketing_api/api/'.$endpoint);
    $headers=['Authorization: Bearer '.$token,'Accept: application/json'];
    if ($body!==null) $headers[]='Content-Type: application/json';
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>18,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CUSTOMREQUEST=>$method]);
    if ($body!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($body));
    $raw=curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=curl_error($ch); curl_close($ch);
    $data=is_string($raw)?json_decode($raw,true):null;
    return ['ok'=>$status>=200 && $status<300 && is_array($data) && !empty($data['success']),'data'=>is_array($data)?$data:[],'status'=>$status,'error'=>$err];
}
$error=''; $success='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!hash_equals((string)$_SESSION['customer_booking_csrf'],(string)($_POST['csrf']??''))) {
        $error='Invalid request token. Refresh the page and try again.';
    } else {
        $id=filter_var($_POST['booking_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
        $lookup=cbApi('bookings.php',$token);
        if (!$lookup['ok']) $error=$lookup['data']['message']??'Could not verify your bookings.';
        else {
            $owned=null;
            foreach (($lookup['data']['data']??[]) as $b) {
                if (is_array($b) && (int)($b['booking_id']??0)===$id) { $owned=$b; break; }
            }
            if (!$owned) $error='Booking not found in your account.';
            elseif (strtolower((string)($owned['booking_status']??''))!=='confirmed') $error='Only confirmed bookings can be cancelled.';
            else {
                $res=cbApi('bookings.php?id='.$id,$token,'PUT',['quantity'=>(int)$owned['quantity'],'booking_status'=>'cancelled']);
                if ($res['ok']) { header('Location: customer_bookings.php?cancelled=1'); exit; }
                $error=$res['data']['message']??($res['error']?:'Cancellation failed.');
            }
        }
    }
}
if (isset($_GET['created'])) $success='Your booking was created successfully!';
if (isset($_GET['cancelled'])) $success='Your booking was cancelled successfully.';
$result=cbApi('bookings.php',$token);
$bookings=$result['data']['data']??[];
if (!is_array($bookings)) $bookings=[];
if (!$result['ok']) $error=$result['data']['message']??($result['error']?:'Could not load bookings.');
usort($bookings,static function($a,$b){return strcmp((string)($b['booked_at']??''),(string)($a['booked_at']??''));});
$confirmed=0;$cancelled=0;$tickets=0;$value=0.0;
foreach($bookings as $b){$s=strtolower((string)($b['booking_status']??''));if($s==='confirmed'){$confirmed++;$tickets+=(int)($b['quantity']??0);$value+=(float)($b['total_price']??0);}elseif($s==='cancelled')$cancelled++;}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>My Bookings | EventTix</title><style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;color:#20243d;font-family:Arial,sans-serif}.layout{display:flex;min-height:100vh}.sidebar{width:250px;flex-shrink:0;background:white;border-right:1px solid #ebebf3;padding:30px 18px}.logo{font-size:23px;font-weight:800;margin:0 0 43px 14px}.logo span{color:#8758f7}.label{color:#9b9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav{display:block;text-decoration:none;color:#65708b;padding:14px 16px;border-radius:12px;margin-bottom:7px;font-size:14px}.nav:hover,.nav.active{background:#f0eaff;color:#7144e8;font-weight:700}.main{flex:1;min-width:0;padding:35px 45px}.top{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:26px}.top h1{font-size:29px;margin:0 0 8px}.muted{color:#8991a4;margin:0}.profile{background:white;border-radius:14px;padding:13px 18px;font-size:13px}.profile strong{color:#7144e8}.hero{background:linear-gradient(110deg,#6741e8,#a276ff);color:white;border-radius:20px;padding:26px 30px;margin-bottom:23px;display:flex;justify-content:space-between;align-items:center;gap:16px}.hero h2{margin:0 0 8px}.hero p{margin:0;color:#eee6ff}.hero a{background:white;color:#7144e8;text-decoration:none;padding:12px 18px;border-radius:10px;font-weight:bold;font-size:13px;white-space:nowrap}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:17px;margin-bottom:23px}.stat{background:white;border-radius:17px;padding:23px;box-shadow:0 4px 20px #19254b08}.stat .num{font-size:27px;font-weight:800;margin-top:10px;color:#7144e8}.stat .lbl{font-size:13px;color:#8790a6}.panel{background:#fff;border-radius:20px;padding:25px;overflow-x:auto;box-shadow:0 4px 20px #19254b08}.toolbar{display:flex;gap:12px;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap}.toolbar h2{margin:0;font-size:18px}.filters{display:flex;gap:10px;flex-wrap:wrap}.filters input,.filters select{padding:11px 13px;border:1px solid #e0e2ec;border-radius:10px;font-size:13px;background:white;min-width:150px}.filters input{min-width:230px}.alert{padding:14px 18px;border-radius:12px;margin-bottom:20px;background:#fff0f0;color:#bc354a}.success{padding:14px 18px;border-radius:12px;margin-bottom:20px;background:#e9f8f0;color:#207b4c}table{width:100%;border-collapse:collapse;min-width:900px}th,td{text-align:left;padding:15px 12px;border-bottom:1px solid #f0f0f5;font-size:13px}th{color:#9499aa;font-size:12px}.pill{border-radius:18px;padding:7px 11px;display:inline-block;font-weight:600;font-size:12px}.pill.confirmed{background:#e9f8f0;color:#207b4c}.pill.cancelled{background:#fff0f0;color:#c34554}.pill.other{background:#f0eaff;color:#7042e3}.cancel{border:1px solid #f1c7ce;background:#fff4f5;color:#bd4053;padding:9px 12px;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer}.cancel:hover{background:#ffe5e9}.empty{color:#8b91a4;text-align:center;padding:35px 0}.note{color:#8b91a4;font-size:12px;margin:16px 0 0}@media(max-width:1050px){.stats{grid-template-columns:repeat(2,1fr)}}@media(max-width:750px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.label{display:none}.nav{display:inline-block;margin:3px}.main{padding:20px}.top{align-items:flex-start;flex-direction:column}.hero{flex-direction:column;align-items:flex-start}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.filters input{min-width:0;width:100%}}
</style></head><body><div class="layout"><aside class="sidebar"><div class="logo">✦ EVENT<span>TIX</span></div><div class="label">CUSTOMER MENU</div><a class="nav" href="customer.php">◈ Dashboard</a><a class="nav" href="customer_events.php">◇ Browse Events</a><a class="nav active" href="customer_bookings.php">▤ My Bookings</a><div class="label">ACCOUNT</div><a class="nav" href="../logout.php">↪ Logout</a></aside><main class="main"><header class="top"><div><h1>My Bookings</h1><p class="muted">Review your tickets and manage your bookings.</p></div><div class="profile">● <?= $name ?> · <strong>Customer</strong></div></header>
<section class="hero"><div><h2>Your Event Tickets</h2><p>All your bookings in one convenient place.</p></div><a href="customer_events.php">Explore Events →</a></section>
<?php if($error): ?><div class="alert"><?= cbEsc($error) ?></div><?php endif; ?><?php if($success): ?><div class="success"><?= cbEsc($success) ?></div><?php endif; ?>
<section class="stats"><div class="stat"><div class="lbl">Total Bookings</div><div class="num"><?= $result['ok']?count($bookings):'—' ?></div></div><div class="stat"><div class="lbl">Confirmed Bookings</div><div class="num"><?= $result['ok']?$confirmed:'—' ?></div></div><div class="stat"><div class="lbl">Confirmed Tickets</div><div class="num"><?= $result['ok']?$tickets:'—' ?></div></div><div class="stat"><div class="lbl">Confirmed Booking Value</div><div class="num"><?= $result['ok']?'RM '.number_format($value,2):'—' ?></div></div></section>
<section class="panel"><div class="toolbar"><h2>Booking History</h2><div class="filters"><input type="search" id="search" placeholder="Search event or booking ID..." aria-label="Search bookings"><select id="statusFilter" aria-label="Filter booking status"><option value="">All Statuses</option><option value="confirmed">Confirmed</option><option value="cancelled">Cancelled</option></select></div></div><table><thead><tr><th>Booking ID</th><th>Event</th><th>Schedule Date &amp; Time</th><th>Quantity</th><th>Total Price</th><th>Status</th><th>Booked At</th><th>Action</th></tr></thead><tbody id="bookingRows">
<?php foreach($bookings as $b): $status=strtolower((string)($b['booking_status']??'')); $pill=in_array($status,['confirmed','cancelled'],true)?$status:'other'; ?><tr data-status="<?= cbEsc($status) ?>" data-search="<?= cbEsc(strtolower(($b['event_title']??'').' '.($b['booking_id']??''))) ?>"><td>#<?= cbEsc($b['booking_id']??'') ?></td><td><?= cbEsc($b['event_title']??'—') ?></td><td><?= cbEsc($b['start_time']??'—') ?></td><td><?= (int)($b['quantity']??0) ?></td><td>RM <?= number_format((float)($b['total_price']??0),2) ?></td><td><span class="pill <?= cbEsc($pill) ?>"><?= cbEsc(ucfirst($status?:'Unknown')) ?></span></td><td><?= cbEsc($b['booked_at']??'—') ?></td><td><?php if($status==='confirmed'): ?><form method="post" onsubmit="return confirm('Cancel this booking? This action will release your reserved tickets.');"><input type="hidden" name="csrf" value="<?= cbEsc($_SESSION['customer_booking_csrf']) ?>"><input type="hidden" name="booking_id" value="<?= (int)$b['booking_id'] ?>"><button type="submit" class="cancel">Cancel Booking</button></form><?php else: ?><span class="muted">—</span><?php endif; ?></td></tr><?php endforeach; ?>
<?php if(!$bookings): ?><tr><td colspan="8" class="empty"><?= $result['ok']?'No bookings yet. Browse events to book your first ticket.':'Bookings could not be loaded.' ?></td></tr><?php endif; ?><tr id="noMatch" hidden><td colspan="8" class="empty">No matching bookings found.</td></tr></tbody></table><p class="note">Cancellation is subject to the booking API rules. Confirmed booking value represents booked value, not necessarily payments collected.</p></section></main></div>
<script>const search=document.getElementById('search'),statusFilter=document.getElementById('statusFilter'),rows=[...document.querySelectorAll('#bookingRows tr[data-status]')],noMatch=document.getElementById('noMatch');function filterRows(){const q=search.value.toLowerCase().trim(),s=statusFilter.value;let shown=0;rows.forEach(row=>{const visible=(!s||row.dataset.status===s)&&row.dataset.search.includes(q);row.hidden=!visible;if(visible)shown++;});noMatch.hidden=shown>0||rows.length===0;}search.addEventListener('input',filterRows);statusFilter.addEventListener('change',filterRows);</script></body></html>
