
<?php
$requiredRole = 'admin';
require __DIR__ . '/../includes/auth_guard.php';

$name = htmlspecialchars(
    $_SESSION['full_name'] ?? 'Administrator',
    ENT_QUOTES,
    'UTF-8'
);

$apiBase = 'http://localhost/event_ticketing_api/api';
$token = $_SESSION['jwt'] ?? $_SESSION['access_token'] ?? '';

function fetchApi(string $endpoint, string $token, string $apiBase): array
{
    if ($token === '') {
        return [];
    }

    $ch = curl_init($apiBase . '/' . $endpoint);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $token,
            'Accept: application/json'
        ]
    ]);

    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($status !== 200 || !is_string($response)) {
        return [];
    }

    $decoded = json_decode($response, true);

    return is_array($decoded) ? $decoded : [];
}

$usersResponse = fetchApi('users.php', $token, $apiBase);
$eventsResponse = fetchApi('events.php', $token, $apiBase);
$venuesResponse = fetchApi('venues.php', $token, $apiBase);
$bookingsResponse = fetchApi('bookings.php', $token, $apiBase);

$users = $usersResponse['data'] ?? [];
$events = $eventsResponse['data'] ?? [];
$venues = $venuesResponse['data'] ?? [];
$bookings = $bookingsResponse['data'] ?? [];

$totalUsers = $usersResponse['total'] ?? count($users);
$totalEvents = $eventsResponse['total'] ?? count($events);
$totalVenues = $venuesResponse['total'] ?? count($venues);
$totalBookings = $bookingsResponse['total'] ?? count($bookings);

$recentEvents = array_slice($events, -5);
$recentEvents = array_reverse($recentEvents);

function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | EventTix</title>

    <link rel="stylesheet" href="../assets/style.css">

    <style>
        * { box-sizing: border-box; }

        body.admin-body {
            margin: 0;
            background: #f6f7fc;
            color: #18213d;
            font-family: Arial, sans-serif;
        }

        .admin-layout {
            display: flex;
            min-height: 100vh;
        }

        .admin-sidebar {
            width: 250px;
            background: #ffffff;
            border-right: 1px solid #e9eaf2;
            padding: 30px 18px;
            flex-shrink: 0;
        }

        .admin-logo {
            font-size: 23px;
            font-weight: 800;
            margin-bottom: 45px;
            padding-left: 14px;
        }

        .admin-logo span {
            color: #8758f7;
        }

        .sidebar-label {
            color: #9a9eae;
            font-size: 11px;
            letter-spacing: 2px;
            margin: 25px 14px 12px;
        }

        .sidebar-link {
            display: block;
            text-decoration: none;
            color: #65708b;
            padding: 14px 16px;
            margin-bottom: 7px;
            border-radius: 12px;
            font-size: 14px;
            transition: .2s;
        }

        .sidebar-link:hover,
        .sidebar-link.active {
            background: #f0eaff;
            color: #7144e8;
            font-weight: bold;
        }

        .admin-main {
            flex: 1;
            padding: 35px 45px;
            min-width: 0;
        }

        .admin-topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            margin-bottom: 35px;
        }

        .admin-topbar h1 {
            font-size: 29px;
            margin: 0 0 8px;
        }

        .admin-topbar p {
            margin: 0;
            color: #8b91a4;
        }

        .admin-profile {
            background: #fff;
            padding: 13px 18px;
            border-radius: 14px;
            font-size: 13px;
            box-shadow: 0 4px 20px #19254b08;
        }

        .admin-profile strong {
            color: #7144e8;
        }

        .welcome-banner {
            background: linear-gradient(110deg, #6741e8, #a276ff);
            padding: 32px;
            color: #fff;
            border-radius: 22px;
            margin-bottom: 30px;
        }

        .welcome-banner h2 {
            margin: 0 0 10px;
            font-size: 25px;
        }

        .welcome-banner p {
            margin: 0;
            color: #eee6ff;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 35px;
        }

        .stat-card {
            background: #fff;
            border-radius: 18px;
            padding: 25px;
            box-shadow: 0 4px 20px #19254b08;
        }

        .stat-icon {
            width: 43px;
            height: 43px;
            display: grid;
            place-items: center;
            border-radius: 13px;
            background: #f0eaff;
            color: #7749ed;
            font-size: 22px;
            margin-bottom: 20px;
        }

        .stat-card p {
            color: #8b91a4;
            margin: 0 0 10px;
            font-size: 13px;
        }

        .stat-card h3 {
            margin: 0;
            font-size: 30px;
        }

        .content-card {
            background: #fff;
            border-radius: 20px;
            padding: 26px;
            box-shadow: 0 4px 20px #19254b08;
            overflow-x: auto;
        }

        .section-title {
            font-size: 19px;
            margin: 0 0 23px;
        }

        .events-table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            min-width: 580px;
        }

        .events-table th {
            font-size: 12px;
            color: #9a9eae;
            font-weight: 600;
            padding: 14px;
            border-bottom: 1px solid #eeeef4;
        }

        .events-table td {
            padding: 17px 14px;
            border-bottom: 1px solid #f1f1f6;
            font-size: 13px;
        }

        .status {
            display: inline-block;
            padding: 7px 11px;
            border-radius: 30px;
            background: #f0eaff;
            color: #7449e8;
            font-size: 12px;
            text-transform: capitalize;
        }

        .empty-state {
            color: #8b91a4;
            padding: 20px 0;
        }

        @media (max-width: 1050px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .admin-main {
                padding: 25px;
            }
        }

        @media (max-width: 650px) {
            .admin-layout {
                display: block;
            }

            .admin-sidebar {
                width: 100%;
                padding: 16px;
                border-right: none;
                border-bottom: 1px solid #eee;
            }

            .admin-logo {
                margin-bottom: 15px;
            }

            .sidebar-link {
                display: inline-block;
                margin: 3px;
            }

            .sidebar-label {
                display: none;
            }

            .admin-topbar {
                align-items: flex-start;
                flex-direction: column;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .admin-main {
                padding: 18px;
            }
        }
    </style>
</head>

<body class="admin-body">

<div class="admin-layout">

    <aside class="admin-sidebar">

        <div class="admin-logo">
            ✦ EVENT<span>TIX</span>
        </div>

        <div class="sidebar-label">MAIN MENU</div>

        <a class="sidebar-link active" href="admin.php">
            ◈ Dashboard
        </a>

        <a class="sidebar-link" href="manage_users.php">
            ♙ Manage Users
        </a>

        <a class="sidebar-link" href="manage_events.php">
            ◇ Manage Events
        </a>

        <a class="sidebar-link" href="manage_venues.php">
            ▣ Manage Venues
        </a>

        <a class="sidebar-link" href="manage_bookings.php">
            ▤ Manage Bookings
        </a>

        <div class="sidebar-label">ACCOUNT</div>

        <a class="sidebar-link" href="../logout.php">
            ↪ Logout
        </a>

    </aside>

    <main class="admin-main">

        <header class="admin-topbar">
            <div>
                <h1>Dashboard Overview</h1>
                <p>Welcome back! Here's your event management overview.</p>
            </div>

            <div class="admin-profile">
                ● <?= $name ?> · <strong>Admin</strong>
            </div>
        </header>

        <section class="welcome-banner">
            <h2>Welcome to EventTix ✨</h2>
            <p>Manage your events, venues, users and bookings in one place.</p>
        </section>

        <section class="stats-grid">

            <div class="stat-card">
                <div class="stat-icon">♙</div>
                <p>Total Users</p>
                <h3><?= e($totalUsers) ?></h3>
            </div>

            <div class="stat-card">
                <div class="stat-icon">◇</div>
                <p>Total Events</p>
                <h3><?= e($totalEvents) ?></h3>
            </div>

            <div class="stat-card">
                <div class="stat-icon">▣</div>
                <p>Total Venues</p>
                <h3><?= e($totalVenues) ?></h3>
            </div>

            <div class="stat-card">
                <div class="stat-icon">▤</div>
                <p>Total Bookings</p>
                <h3><?= e($totalBookings) ?></h3>
            </div>

        </section>

        <section class="content-card">

            <h2 class="section-title">Recent Events</h2>

            <?php if (empty($recentEvents)): ?>

                <p class="empty-state">
                    No event data available. Check your API connection and authentication.
                </p>

            <?php else: ?>

                <table class="events-table">
                    <thead>
                        <tr>
                            <th>Event ID</th>
                            <th>Event Name</th>
                            <th>Venue</th>
                            <th>Category</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php foreach ($recentEvents as $event): ?>
                        <tr>
                            <td>#<?= e($event['event_id'] ?? '-') ?></td>
                            <td><?= e($event['title'] ?? '-') ?></td>
                            <td><?= e($event['venue_name'] ?? '-') ?></td>
                            <td><?= e($event['category'] ?? '-') ?></td>
                            <td>
                                <span class="status">
                                    <?= e($event['status'] ?? '-') ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

            <?php endif; ?>

        </section>

    </main>

</div>

</body>
</html>
