<?php
$requiredRole = 'organiser';
require __DIR__ . '/../includes/auth_guard.php';
$token = $_SESSION['access_token'];
function esc($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function api(string $method, string $path, string $token, ?array $body = null): array {
    $url = 'http://localhost/event_ticketing_api/api/' . $path;
    $headers = ['Authorization: Bearer ' . $token, 'Accept: application/json'];
    if ($body !== null) $headers[] = 'Content-Type: application/json';
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_CUSTOMREQUEST=>$method, CURLOPT_HTTPHEADER=>$headers, CURLOPT_TIMEOUT=>12, CURLOPT_FOLLOWLOCATION=>false]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    $raw = curl_exec($ch); $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch); curl_close($ch);
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    return ['status'=>$status, 'json'=>is_array($decoded) ? $decoded : ['success'=>false,'message'=>$err ?: 'Invalid API response']];
}
// JWT payload is used only to identify the current organiser for UI filtering.
// All write permissions and ownership are enforced independently by events.php.
function jwtUserId(string $token): int {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return 0;
    $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
    if (!is_array($payload)) return 0;
    foreach (['user_id','id','sub'] as $key) {
        if (isset($payload[$key]) && filter_var($payload[$key], FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]])) return (int)$payload[$key];
    }
    if (isset($payload['data']['user_id'])) return (int)$payload['data']['user_id'];
    return 0;
}
$organiserId = (int)($_SESSION['user_id'] ?? 0);
if ($organiserId < 1) $organiserId = jwtUserId($token);
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$notice = ''; $noticeClass = 'ok';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], (string)($_POST['csrf_token'] ?? ''))) { http_response_code(403); exit('Invalid CSRF token'); }
    $action = (string)($_POST['action'] ?? '');
    if ($organiserId < 1) {
        $notice = 'Could not identify your organiser ID. Please log out and log in again.'; $noticeClass = 'bad';
    } elseif (in_array($action, ['create','update'], true)) {
        $body = [
            'organiser_id'=>$organiserId,
            'venue_id'=>(int)($_POST['venue_id'] ?? 0),
            'title'=>trim((string)($_POST['title'] ?? '')),
            'description'=>trim((string)($_POST['description'] ?? '')),
            'category'=>trim((string)($_POST['category'] ?? '')),
            'status'=>(string)($_POST['status'] ?? 'draft')
        ];
        $id = filter_var($_POST['event_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
        if ($body['venue_id'] < 1 || $body['title'] === '' || !in_array($body['status'], ['draft','published','cancelled'], true) || ($action === 'update' && !$id)) {
            $notice = 'Please provide valid event details.'; $noticeClass = 'bad';
        } else {
            $path = 'events.php' . ($action === 'update' ? '?id=' . $id : '');
            $r = api($action === 'create' ? 'POST' : 'PUT', $path, $token, $body);
            $notice = $r['json']['message'] ?? 'Request completed';
            $noticeClass = !empty($r['json']['success']) ? 'ok' : 'bad';
        }
    } elseif ($action === 'delete') {
        $id = filter_var($_POST['event_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
        if (!$id) { $notice = 'Invalid event ID'; $noticeClass = 'bad'; }
        else {
            $r = api('DELETE', 'events.php?id=' . $id, $token);
            $notice = $r['json']['message'] ?? 'Request completed';
            $noticeClass = !empty($r['json']['success']) ? 'ok' : 'bad';
        }
    }
}
$venuesResult = api('GET', 'venues.php', $token);
$venues = $venuesResult['json']['data'] ?? [];
if (!is_array($venues)) $venues = [];
$allEvents = []; $loadError = '';
for ($page=1; $page<=50; $page++) {
    $r = api('GET', 'events.php?page='.$page.'&limit=100', $token);
    if ($r['status'] !== 200) { $loadError = $r['json']['message'] ?? 'Unable to load events'; break; }
    $batch = $r['json']['data'] ?? [];
    if (!is_array($batch)) { $loadError = 'Unexpected events response'; break; }
    $allEvents = array_merge($allEvents, $batch);
    if ($page >= (int)($r['json']['total_pages'] ?? 1)) break;
}
$myEvents = array_values(array_filter($allEvents, fn($ev) => (int)($ev['organiser_id'] ?? 0) === $organiserId));
usort($myEvents, fn($a,$b) => (int)$b['event_id'] <=> (int)$a['event_id']);
$name = $_SESSION['full_name'] ?? 'Organiser';
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>My Events | EventTix</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:#f6f7fc;color:#18213d}.layout{display:flex;min-height:100vh}.sidebar{width:250px;background:#fff;padding:30px 18px;border-right:1px solid #e9eaf2;flex-shrink:0}.logo{font-size:23px;font-weight:800;margin:0 0 45px 14px}.logo span{color:#8758f7}.menu-label{font-size:11px;letter-spacing:2px;color:#9a9eae;margin:25px 14px 12px}.nav-link{display:block;text-decoration:none;color:#65708b;padding:14px 16px;border-radius:12px;margin-bottom:7px;font-size:14px}.nav-link:hover,.nav-link.active{background:#f0eaff;color:#7144e8;font-weight:bold}.main{flex:1;padding:35px 45px;min-width:0}.top{display:flex;justify-content:space-between;align-items:center;gap:18px;margin-bottom:25px}h1{margin:0 0 8px;font-size:29px}.muted{color:#8b91a4;margin:0}.panel{background:#fff;border-radius:20px;padding:25px;box-shadow:0 4px 20px #19254b08;overflow-x:auto}.btn{border:0;background:#794ce9;color:#fff;padding:12px 18px;border-radius:11px;font-size:13px;font-weight:600;cursor:pointer}.btn:hover{background:#643bd0}.btn.small{padding:8px 12px}.btn.secondary{background:#f0eaff;color:#7042e3}.btn.danger{background:#fff0f0;color:#d33c50}table{border-collapse:collapse;width:100%;min-width:750px}th,td{padding:16px 12px;text-align:left;border-bottom:1px solid #f0f0f5;font-size:13px}th{color:#9499aa;font-size:12px}.actions{display:flex;gap:8px}.status{padding:7px 11px;border-radius:20px;background:#f0eaff;color:#7042e3;text-transform:capitalize}.alert{padding:14px 18px;border-radius:12px;margin-bottom:18px}.alert.ok{background:#e9f8f0;color:#207b4c}.alert.bad{background:#fff0f0;color:#bc354a}.search{padding:12px 14px;border:1px solid #dddfea;border-radius:11px;margin-bottom:18px;max-width:330px;width:100%}.backdrop{position:fixed;inset:0;background:#10162d99;display:none;align-items:center;justify-content:center;padding:20px;z-index:10}.backdrop.open{display:flex}.modal{width:100%;max-width:530px;background:#fff;padding:28px;border-radius:20px;max-height:90vh;overflow:auto}.field{margin:14px 0}.field label{display:block;font-size:13px;font-weight:600;margin-bottom:8px}.field input,.field select,.field textarea{width:100%;border:1px solid #dddfea;border-radius:10px;padding:12px;font:inherit;font-size:14px}.modal-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:22px}@media(max-width:750px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.menu-label{display:none}.nav-link{display:inline-block;margin:3px}.main{padding:20px}.top{align-items:flex-start;flex-direction:column}}
</style></head><body><div class="layout"><aside class="sidebar"><div class="logo">✦ EVENT<span>TIX</span></div><div class="menu-label">ORGANISER MENU</div><a class="nav-link" href="organiser.php">◈ Dashboard</a><a class="nav-link active" href="organiser_events.php">◇ My Events</a><a class="nav-link" href="organiser_schedules.php">▣ Event Schedules</a><a class="nav-link" href="organiser_bookings.php">▤ Event Bookings</a><div class="menu-label">ACCOUNT</div><a class="nav-link" href="../logout.php">↪ Logout</a></aside><main class="main"><div class="top"><div><h1>My Events</h1><p class="muted">Create and manage your own EventTix events, <?= esc($name) ?>.</p></div><button type="button" class="btn" onclick="openCreate()">+ Add Event</button></div>
<?php if($notice !== ''): ?><div class="alert <?= esc($noticeClass) ?>"><?= esc($notice) ?></div><?php endif; ?>
<?php if($organiserId < 1): ?><div class="alert bad">Your organiser ID could not be read from the session or JWT. Check the login session before creating events.</div><?php endif; ?>
<?php if($loadError !== ''): ?><div class="alert bad"><?= esc($loadError) ?></div><?php endif; ?>
<section class="panel"><input class="search" id="search" type="search" placeholder="Search my events..." oninput="filterRows()"><table><thead><tr><th>ID</th><th>Event</th><th>Venue</th><th>Category</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php foreach($myEvents as $ev): ?><tr class="event-row"><td>#<?= esc($ev['event_id'] ?? '') ?></td><td><strong><?= esc($ev['title'] ?? '') ?></strong></td><td><?= esc($ev['venue_name'] ?? '') ?></td><td><?= esc($ev['category'] ?? '') ?></td><td><span class="status"><?= esc($ev['status'] ?? '') ?></span></td><td><div class="actions"><button type="button" class="btn small secondary edit-button" data-event="<?= esc(json_encode(['event_id'=>$ev['event_id'],'title'=>$ev['title'],'venue_id'=>$ev['venue_id'],'category'=>$ev['category'],'description'=>$ev['description'],'status'=>$ev['status']], JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)) ?>">Edit</button><form method="post" onsubmit="return confirm('Delete this event? Events with schedules cannot be deleted.');"><input type="hidden" name="csrf_token" value="<?= esc($_SESSION['csrf_token']) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="event_id" value="<?= esc($ev['event_id']) ?>"><button class="btn small danger">Delete</button></form></div></td></tr><?php endforeach; ?>
<?php if(!$myEvents): ?><tr><td colspan="6">No events found for your organiser account.</td></tr><?php endif; ?></tbody></table></section></main></div>
<div class="backdrop" id="modal"><div class="modal"><h2 id="modalTitle">Add Event</h2><form method="post" id="eventForm"><input type="hidden" name="csrf_token" value="<?= esc($_SESSION['csrf_token']) ?>"><input type="hidden" name="action" id="action" value="create"><input type="hidden" name="event_id" id="eventId"><div class="field"><label for="title">Event Title</label><input id="title" name="title" required maxlength="255"></div><div class="field"><label for="venue">Venue</label><select id="venue" name="venue_id" required><option value="">Select venue</option><?php foreach($venues as $v): ?><option value="<?= esc($v['venue_id']) ?>"><?= esc($v['venue_name']) ?> — <?= esc($v['location']) ?></option><?php endforeach; ?></select></div><div class="field"><label for="category">Category</label><input id="category" name="category" placeholder="Concert, Conference, Festival..." required></div><div class="field"><label for="description">Description</label><textarea id="description" name="description" rows="4"></textarea></div><div class="field"><label for="status">Status</label><select id="status" name="status"><option value="draft">Draft</option><option value="published">Published</option><option value="cancelled">Cancelled</option></select></div><div class="modal-actions"><button type="button" class="btn secondary" onclick="closeModal()">Cancel</button><button class="btn" type="submit">Save Event</button></div></form></div></div>
<script>
const modal=document.getElementById('modal');
function openCreate(){document.getElementById('eventForm').reset();document.getElementById('modalTitle').textContent='Add Event';document.getElementById('action').value='create';document.getElementById('eventId').value='';modal.classList.add('open')}
function closeModal(){modal.classList.remove('open')}
document.querySelectorAll('.edit-button').forEach(btn=>btn.addEventListener('click',()=>{const ev=JSON.parse(btn.dataset.event);document.getElementById('modalTitle').textContent='Edit Event';document.getElementById('action').value='update';document.getElementById('eventId').value=ev.event_id;document.getElementById('title').value=ev.title;document.getElementById('venue').value=ev.venue_id;document.getElementById('category').value=ev.category;document.getElementById('description').value=ev.description;document.getElementById('status').value=ev.status;modal.classList.add('open')}));
modal.addEventListener('click',ev=>{if(ev.target===modal)closeModal()});
function filterRows(){const q=document.getElementById('search').value.toLowerCase();document.querySelectorAll('.event-row').forEach(row=>row.style.display=row.textContent.toLowerCase().includes(q)?'':'none')}
</script></body></html>
