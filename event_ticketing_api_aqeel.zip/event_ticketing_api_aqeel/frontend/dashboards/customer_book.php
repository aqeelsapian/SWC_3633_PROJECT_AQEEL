<?php
$requiredRole = 'customer';
require __DIR__ . '/../includes/auth_guard.php';
$token = (string)$_SESSION['access_token'];
$name = htmlspecialchars((string)($_SESSION['full_name'] ?? 'Customer'), ENT_QUOTES, 'UTF-8');
function bookEsc($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function bookApi(string $path, string $token, string $method = 'GET', ?array $payload = null): array {
    $ch = curl_init('http://localhost/event_ticketing_api/api/' . $path);
    $headers = ['Authorization: Bearer '.$token, 'Accept: application/json'];
    if ($payload !== null) $headers[] = 'Content-Type: application/json';
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>$headers, CURLOPT_TIMEOUT=>18, CURLOPT_FOLLOWLOCATION=>false, CURLOPT_CUSTOMREQUEST=>$method]);
    if ($payload !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    $raw = curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $error=curl_error($ch); curl_close($ch);
    $decoded = is_string($raw) ? json_decode($raw,true) : null;
    return ['ok'=>$status>=200 && $status<300 && is_array($decoded) && !empty($decoded['success']), 'data'=>is_array($decoded)?$decoded:[], 'status'=>$status, 'error'=>$error];
}
function bookJwtId(string $jwt): int {
    $parts=explode('.', $jwt);
    if (count($parts)!==3) return 0;
    $json=base64_decode(strtr($parts[1], '-_', '+/'),true);
    $claims=is_string($json)?json_decode($json,true):null;
    if (!is_array($claims)) return 0;
    foreach ([$claims['user_id']??null, $claims['data']['user_id']??null, $claims['sub']??null, $claims['id']??null] as $candidate) {
        if (filter_var($candidate,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]])!==false) return (int)$candidate;
    }
    return 0;
}
$eventId=filter_input(INPUT_GET,'event_id',FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]) ?: 0;
$event=null; $schedules=[]; $error=''; $success='';
if (!$eventId) $error='Please select an event from Browse Events.';
else {
    $res=bookApi('events.php?id='.$eventId,$token);
    if (!$res['ok']) $error=$res['data']['message']??'Could not load event.';
    else {
        $event=$res['data']['data']??null;
        if (!is_array($event) || strtolower((string)($event['status']??''))!=='published') { $event=null; $error='This event is not available for booking.'; }
        else {
            $sr=bookApi('schedules.php',$token);
            if (!$sr['ok']) $error='Could not load event schedules.';
            else foreach (($sr['data']['data']??[]) as $s) if (is_array($s) && (int)($s['event_id']??0)===$eventId && (int)($s['available_tickets']??0)>0 && strtotime((string)($s['start_time']??''))>=time()) $schedules[]=$s;
            usort($schedules,static fn($a,$b)=>strcmp((string)$a['start_time'],(string)$b['start_time']));
        }
    }
}
$userId=(int)($_SESSION['user_id']??0);
if ($userId<1) $userId=bookJwtId($token);
if ($_SERVER['REQUEST_METHOD']==='POST' && $event && !$error) {
    $selected=filter_input(INPUT_POST,'schedule_id',FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]) ?: 0;
    $quantity=filter_input(INPUT_POST,'quantity',FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]) ?: 0;
    $chosen=null;
    foreach ($schedules as $s) if ((int)$s['schedule_id']===$selected) { $chosen=$s; break; }
    if (!$chosen) $error='Please choose an available event schedule.';
    elseif ($quantity<1 || $quantity>(int)$chosen['available_tickets']) $error='Ticket quantity exceeds available tickets.';
    elseif ($userId<1) $error='Could not determine your customer ID from the login session. Please log in again or check JWT user_id claim.';
    else {
        $result=bookApi('bookings.php',$token,'POST',['user_id'=>$userId,'schedule_id'=>$selected,'quantity'=>$quantity]);
        if ($result['ok']) {
            header('Location: customer_bookings.php?created=1'); exit;
        }
        $error=$result['data']['message']??($result['error']?:'Booking failed. Please try again.');
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Book Tickets | EventTix</title><style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;color:#20243d;font-family:Arial,sans-serif}.layout{display:flex;min-height:100vh}.sidebar{width:250px;flex-shrink:0;background:white;border-right:1px solid #ebebf3;padding:30px 18px}.logo{font-size:23px;font-weight:800;margin:0 0 43px 14px}.logo span{color:#8758f7}.label{color:#9b9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav{display:block;text-decoration:none;color:#65708b;padding:14px 16px;border-radius:12px;margin-bottom:7px;font-size:14px}.nav:hover,.nav.active{background:#f0eaff;color:#7144e8;font-weight:700}.main{flex:1;min-width:0;padding:35px 45px}.top{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:28px}.top h1{font-size:29px;margin:0 0 8px}.muted{color:#8991a4;margin:0}.profile{background:white;border-radius:14px;padding:13px 18px;font-size:13px}.profile strong{color:#7144e8}.banner{background:linear-gradient(110deg,#6741e8,#a276ff);color:white;padding:29px;border-radius:20px;margin-bottom:24px}.banner h2{margin:0 0 10px}.banner p{margin:0;color:#efe8ff;line-height:1.6}.columns{display:grid;grid-template-columns:1.3fr 1fr;gap:22px}.panel{background:#fff;border-radius:18px;padding:26px;box-shadow:0 4px 20px #19254b08}.panel h3{margin:0 0 20px}.info{padding:12px 0;border-bottom:1px solid #f0f0f5;font-size:14px}.info strong{display:block;margin-bottom:5px;color:#8991a4;font-size:12px}.field{margin:0 0 20px}.field label{display:block;font-size:13px;font-weight:bold;margin-bottom:9px}.field select,.field input{width:100%;padding:13px;border:1px solid #dedfeb;border-radius:11px;font-size:14px;background:white}.summary{background:#f6f2ff;border-radius:12px;padding:18px;margin-bottom:18px}.summary div{display:flex;justify-content:space-between;gap:12px;padding:7px 0;font-size:14px}.summary .total{font-size:19px;color:#7144e8;font-weight:bold;border-top:1px solid #ddd3f7;margin-top:10px;padding-top:15px}.button{border:0;background:#794ce9;color:white;padding:14px 20px;border-radius:11px;font-weight:bold;cursor:pointer;width:100%;font-size:14px}.button:disabled{background:#aaa5bc;cursor:not-allowed}.warning{background:#fff1ed;color:#9a3f25;padding:14px 17px;border-radius:12px;margin-bottom:20px}.back{display:inline-block;color:#7144e8;text-decoration:none;font-size:13px;margin-bottom:20px}@media(max-width:850px){.columns{grid-template-columns:1fr}.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.label{display:none}.nav{display:inline-block;margin:3px}.main{padding:18px}.top{flex-direction:column;align-items:flex-start}}
</style></head><body><div class="layout"><aside class="sidebar"><div class="logo">✦ EVENT<span>TIX</span></div><div class="label">CUSTOMER MENU</div><a class="nav" href="customer.php">◈ Dashboard</a><a class="nav active" href="customer_events.php">◇ Browse Events</a><a class="nav" href="customer_bookings.php">▤ My Bookings</a><div class="label">ACCOUNT</div><a class="nav" href="../logout.php">↪ Logout</a></aside><main class="main"><header class="top"><div><h1>Book Tickets</h1><p class="muted">Select your event schedule and confirm your tickets.</p></div><div class="profile">● <?= $name ?> · <strong>Customer</strong></div></header><a class="back" href="customer_events.php">← Back to Browse Events</a>
<?php if ($error): ?><div class="warning"><?= bookEsc($error) ?></div><?php endif; ?>
<?php if ($event): ?><section class="banner"><h2><?= bookEsc($event['title']??'Event') ?></h2><p><?= bookEsc($event['description']??'') ?></p></section><div class="columns"><section class="panel"><h3>Event Details</h3><div class="info"><strong>Category</strong><?= bookEsc($event['category']??'—') ?></div><div class="info"><strong>Venue</strong><?= bookEsc($event['venue_name']??'—') ?></div><div class="info"><strong>Location</strong><?= bookEsc($event['location']??'—') ?></div><div class="info"><strong>Available Schedules</strong><?= count($schedules) ?> upcoming schedule(s) with tickets</div></section><section class="panel"><h3>Ticket Booking</h3><?php if (!$schedules): ?><p class="muted">No upcoming schedules with available tickets.</p><?php else: ?><form method="post" action="customer_book.php?event_id=<?= $eventId ?>"><div class="field"><label for="schedule">Select Schedule</label><select id="schedule" name="schedule_id" required><?php foreach ($schedules as $s): ?><option value="<?= (int)$s['schedule_id'] ?>" data-price="<?= bookEsc((float)$s['ticket_price']) ?>" data-stock="<?= (int)$s['available_tickets'] ?>" <?= (int)($_POST['schedule_id']??0)===(int)$s['schedule_id']?'selected':'' ?>><?= bookEsc(date('d M Y, h:i A',strtotime((string)$s['start_time']))) ?> — RM <?= number_format((float)$s['ticket_price'],2) ?> (<?= (int)$s['available_tickets'] ?> left)</option><?php endforeach; ?></select></div><div class="field"><label for="quantity">Ticket Quantity</label><input id="quantity" name="quantity" type="number" min="1" step="1" value="<?= bookEsc($_POST['quantity']??1) ?>" required></div><div class="summary"><div><span>Price per Ticket</span><strong id="unit">RM 0.00</strong></div><div><span>Available Tickets</span><strong id="stock">—</strong></div><div class="total"><span>Total</span><strong id="total">RM 0.00</strong></div></div><button class="button" id="confirm" type="submit">Confirm Booking →</button></form><?php endif; ?></section></div><?php endif; ?></main></div><script>
const schedule=document.getElementById('schedule'),quantity=document.getElementById('quantity'),unit=document.getElementById('unit'),stock=document.getElementById('stock'),total=document.getElementById('total'),confirmBtn=document.getElementById('confirm');function recalc(){if(!schedule)return;const opt=schedule.selectedOptions[0],price=Number(opt?.dataset.price||0),available=Number(opt?.dataset.stock||0),qty=Number(quantity.value||0);quantity.max=String(available);unit.textContent='RM '+price.toFixed(2);stock.textContent=String(available);total.textContent='RM '+(price*Math.max(0,qty)).toFixed(2);confirmBtn.disabled=!Number.isInteger(qty)||qty<1||qty>available;}if(schedule){schedule.addEventListener('change',recalc);quantity.addEventListener('input',recalc);recalc();}
</script></body></html>
