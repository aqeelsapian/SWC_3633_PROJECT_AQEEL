<?php
$requiredRole = 'customer';
require __DIR__ . '/../includes/auth_guard.php';
$token = (string)$_SESSION['access_token'];
$name = htmlspecialchars((string)($_SESSION['full_name'] ?? 'Customer'), ENT_QUOTES, 'UTF-8');
function evtEsc($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function evtApi(string $path, string $token): array {
    $ch = curl_init('http://localhost/event_ticketing_api/api/' . $path);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token,'Accept: application/json'], CURLOPT_TIMEOUT=>15, CURLOPT_FOLLOWLOCATION=>false]);
    $raw = curl_exec($ch); $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $error = curl_error($ch); curl_close($ch);
    $decoded = is_string($raw) ? json_decode($raw,true) : null;
    return ['ok'=>$status===200 && is_array($decoded) && !empty($decoded['success']), 'data'=>is_array($decoded)?$decoded:[], 'error'=>$error];
}
$events = []; $eventsError = '';
for ($page=1;$page<=50;$page++) {
    $r=evtApi('events.php?page='.$page.'&limit=100',$token);
    if (!$r['ok']) { $eventsError=$r['data']['message'] ?? $r['error'] ?: 'Could not load events.'; break; }
    $batch=$r['data']['data'] ?? [];
    if (!is_array($batch)) { $eventsError='Unexpected events response.'; break; }
    foreach ($batch as $event) if (strtolower((string)($event['status']??''))==='published') $events[]=$event;
    if ($page >= (int)($r['data']['total_pages'] ?? 1)) break;
}
$schedulesResult=evtApi('schedules.php',$token);
$schedulesByEvent=[];
if ($schedulesResult['ok']) {
    foreach (($schedulesResult['data']['data'] ?? []) as $s) {
        if (!is_array($s)) continue;
        $id=(int)($s['event_id']??0);
        if ($id>0) $schedulesByEvent[$id][]=$s;
    }
}
foreach ($schedulesByEvent as &$rows) usort($rows,static fn($a,$b)=>strcmp((string)($a['start_time']??''),(string)($b['start_time']??'')));
unset($rows);
$categories=[];
foreach ($events as $e) { $c=trim((string)($e['category']??'')); if ($c!=='') $categories[$c]=true; }
ksort($categories);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Browse Events | EventTix</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;color:#20243d;font-family:Arial,sans-serif}.layout{display:flex;min-height:100vh}.sidebar{width:250px;flex-shrink:0;background:#fff;border-right:1px solid #ebebf3;padding:30px 18px}.logo{font-size:23px;font-weight:800;margin:0 0 43px 14px}.logo span{color:#8758f7}.label{color:#9b9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav{display:block;text-decoration:none;color:#65708b;padding:14px 16px;border-radius:12px;margin-bottom:7px;font-size:14px}.nav:hover,.nav.active{background:#f0eaff;color:#7144e8;font-weight:700}.main{flex:1;min-width:0;padding:35px 45px}.top{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:27px}.top h1{font-size:29px;margin:0 0 8px}.muted{color:#8991a4;margin:0}.profile{background:#fff;border-radius:14px;padding:13px 18px;font-size:13px}.profile strong{color:#7144e8}.banner{background:linear-gradient(110deg,#6741e8,#a276ff);color:#fff;padding:30px;border-radius:22px;margin-bottom:25px}.banner h2{margin:0 0 8px}.banner p{margin:0;color:#eee6ff}.filters{background:#fff;border-radius:18px;padding:19px;display:flex;gap:12px;flex-wrap:wrap;margin-bottom:23px;box-shadow:0 4px 20px #19254b08}.filters input,.filters select{border:1px solid #e0e1ed;border-radius:10px;padding:12px;font-size:14px;min-width:170px}.filters input{flex:1}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}.card{background:#fff;border-radius:19px;padding:23px;box-shadow:0 4px 20px #19254b08;display:flex;flex-direction:column;gap:13px}.category{background:#f0eaff;color:#7144e8;font-size:12px;font-weight:bold;border-radius:15px;padding:7px 11px;align-self:flex-start}.card h3{font-size:20px;margin:0}.desc{color:#707b92;font-size:13px;line-height:1.6;margin:0}.meta{font-size:13px;color:#5d6980}.schedule{border-top:1px solid #f0f0f5;padding-top:12px;font-size:13px}.schedule p{margin:5px 0;color:#66718a}.price{font-size:18px;font-weight:bold;color:#7042e3}.button{display:inline-block;text-align:center;text-decoration:none;background:#794ce9;color:white;padding:12px 15px;border-radius:10px;font-size:13px;font-weight:bold;margin-top:auto}.button:hover{background:#6338d3}.button.disabled{background:#eae8f0;color:#9392a0;cursor:not-allowed}.warning{background:#fff1ed;color:#9a3f25;padding:14px 17px;border-radius:12px;margin-bottom:20px}.empty{background:#fff;border-radius:18px;padding:32px;color:#8991a4}.count{margin:0 0 17px;font-size:13px;color:#8991a4}@media(max-width:1100px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:700px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.label{display:none}.nav{display:inline-block;margin:3px}.main{padding:18px}.top{flex-direction:column;align-items:flex-start}.grid{grid-template-columns:1fr}}
</style></head><body><div class="layout"><aside class="sidebar"><div class="logo">✦ EVENT<span>TIX</span></div><div class="label">CUSTOMER MENU</div><a class="nav" href="customer.php">◈ Dashboard</a><a class="nav active" href="customer_events.php">◇ Browse Events</a><a class="nav" href="customer_bookings.php">▤ My Bookings</a><div class="label">ACCOUNT</div><a class="nav" href="../logout.php">↪ Logout</a></aside><main class="main"><header class="top"><div><h1>Browse Events</h1><p class="muted">Discover experiences and find your next ticket.</p></div><div class="profile">● <?= $name ?> · <strong>Customer</strong></div></header><section class="banner"><h2>Find something amazing ✨</h2><p>Explore published events and their available schedules.</p></section>
<?php if ($eventsError): ?><div class="warning"><?= evtEsc($eventsError) ?></div><?php endif; ?>
<?php if (!$schedulesResult['ok']): ?><div class="warning">Schedules could not be loaded. Check the API connection.</div><?php endif; ?>
<div class="filters"><input id="search" placeholder="Search event, venue or location..." aria-label="Search events"><select id="category" aria-label="Filter by category"><option value="">All Categories</option><?php foreach(array_keys($categories) as $category): ?><option value="<?= evtEsc(strtolower($category)) ?>"><?= evtEsc($category) ?></option><?php endforeach; ?></select></div><p class="count" id="count"><?= count($events) ?> published event(s)</p>
<?php if (!$events): ?><div class="empty">No published events are available yet.</div><?php else: ?><div class="grid" id="eventGrid"><?php foreach ($events as $e): $eventId=(int)($e['event_id']??0); $schedules=$schedulesByEvent[$eventId]??[]; $upcoming=array_values(array_filter($schedules,static fn($s)=>!empty($s['start_time']) && strtotime((string)$s['start_time'])>=time())); $available=array_values(array_filter($upcoming,static fn($s)=>(int)($s['available_tickets']??0)>0)); $next=$available[0]??($upcoming[0]??null); $searchText=strtolower(implode(' ',[$e['title']??'',$e['venue_name']??'',$e['location']??'',$e['description']??''])); ?><article class="card" data-search="<?= evtEsc($searchText) ?>" data-category="<?= evtEsc(strtolower((string)($e['category']??''))) ?>"><span class="category"><?= evtEsc($e['category'] ?: 'Event') ?></span><h3><?= evtEsc($e['title']??'Untitled Event') ?></h3><p class="desc"><?= evtEsc($e['description']??'') ?></p><div class="meta">📍 <?= evtEsc($e['venue_name']??'Venue not assigned') ?><?= !empty($e['location'])?' · '.evtEsc($e['location']):'' ?></div><div class="schedule"><?php if ($next): ?><p>📅 <?= evtEsc(date('d M Y, h:i A',strtotime((string)$next['start_time']))) ?></p><p>🎟 <?= evtEsc($next['available_tickets']??0) ?> tickets available</p><div class="price">RM <?= number_format((float)($next['ticket_price']??0),2) ?></div><?php else: ?><p>No upcoming schedule currently available.</p><?php endif; ?></div><?php if ($available): ?><a class="button" href="customer_book.php?event_id=<?= $eventId ?>">View Details &amp; Book →</a><?php else: ?><span class="button disabled">Not Available</span><?php endif; ?></article><?php endforeach; ?></div><div class="empty" id="noMatch" style="display:none">No events match your search.</div><?php endif; ?></main></div><script>
const search=document.getElementById('search'),category=document.getElementById('category'),cards=[...document.querySelectorAll('.card')];function filterEvents(){let shown=0;for(const card of cards){const match=card.dataset.search.includes(search.value.toLowerCase().trim())&&(!category.value||card.dataset.category===category.value);card.style.display=match?'':'none';if(match)shown++;}document.getElementById('count').textContent=shown+' published event(s)';const noMatch=document.getElementById('noMatch');if(noMatch)noMatch.style.display=shown?'none':'';}search.addEventListener('input',filterEvents);category.addEventListener('change',filterEvents);
</script></body></html>
