
<?php
$requiredRole = 'admin';
require __DIR__ . '/../includes/auth_guard.php';

$token = $_SESSION['access_token'];
$apiUrl = 'http://localhost/event_ticketing_api/api/users.php';
$name = $_SESSION['full_name'] ?? 'Administrator';

function apiRequest(string $method, string $url, string $token, ?array $body = null): array
{
    $headers = [
        'Authorization: Bearer ' . $token,
        'Accept: application/json'
    ];

    if ($body !== null) {
        $headers[] = 'Content-Type: application/json';
    }

    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_FOLLOWLOCATION => false
    ]);

    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }

    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $decoded = is_string($response) ? json_decode($response, true) : null;

    return [
        'status' => $status,
        'data' => is_array($decoded) ? $decoded : [
            'success' => false,
            'message' => 'Unable to connect to the API'
        ]
    ];
}

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$notice = '';
$noticeType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid form token');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {

        $body = [
            'full_name' => trim($_POST['full_name'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'role' => $_POST['role'] ?? '',
        ];

        $password = $_POST['password'] ?? '';

        if ($action === 'create' || $password !== '') {
            $body['password'] = $password;
        }

        if ($action === 'create') {
            $result = apiRequest('POST', $apiUrl, $token, $body);
        } else {
            $id = filter_var($_POST['user_id'] ?? null, FILTER_VALIDATE_INT);

            $result = $id
                ? apiRequest('PUT', $apiUrl . '?id=' . $id, $token, $body)
                : [
                    'status' => 400,
                    'data' => [
                        'success' => false,
                        'message' => 'Invalid user ID'
                    ]
                ];
        }

    } elseif ($action === 'delete') {

        $id = filter_var($_POST['user_id'] ?? null, FILTER_VALIDATE_INT);

        $result = $id
            ? apiRequest('DELETE', $apiUrl . '?id=' . $id, $token)
            : [
                'status' => 400,
                'data' => [
                    'success' => false,
                    'message' => 'Invalid user ID'
                ]
            ];

    } else {
        $result = [
            'status' => 400,
            'data' => [
                'success' => false,
                'message' => 'Invalid action'
            ]
        ];
    }

    $notice = $result['data']['message'] ?? 'Request completed';
    $noticeType = !empty($result['data']['success']) ? 'success' : 'error';

    if ($result['status'] === 401) {
        $notice = 'Session expired. Please log in again.';
    }
}

$listResult = apiRequest('GET', $apiUrl, $token);
$users = $listResult['data']['data'] ?? [];

if (!is_array($users)) {
    $users = [];
}

if ($listResult['status'] !== 200 && $notice === '') {
    $notice = $listResult['data']['message'] ?? 'Unable to load users';
    $noticeType = 'error';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Users | EventTix</title>

<style>
* { box-sizing: border-box; }
body {
    margin: 0;
    background: #f6f7fc;
    font-family: Arial, sans-serif;
    color: #18213d;
}
.layout { display: flex; min-height: 100vh; }
.sidebar {
    width: 250px;
    background: white;
    padding: 30px 18px;
    border-right: 1px solid #e9eaf2;
    flex-shrink: 0;
}
.logo {
    font-size: 23px;
    font-weight: 800;
    margin: 0 0 45px 14px;
}
.logo span { color: #8758f7; }
.menu-label {
    color: #9a9eae;
    font-size: 11px;
    letter-spacing: 2px;
    margin: 25px 14px 12px;
}
.nav-link {
    display: block;
    text-decoration: none;
    color: #65708b;
    padding: 14px 16px;
    border-radius: 12px;
    margin-bottom: 7px;
    font-size: 14px;
}
.nav-link:hover, .nav-link.active {
    background: #f0eaff;
    color: #7144e8;
    font-weight: bold;
}
.main {
    flex: 1;
    padding: 35px 45px;
    min-width: 0;
}
.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 28px;
}
h1 { margin: 0 0 8px; font-size: 29px; }
.subtitle { color: #8b91a4; margin: 0; }
.btn {
    background: #794ce9;
    border: 0;
    border-radius: 11px;
    color: white;
    padding: 12px 18px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
}
.btn:hover { background: #643bd0; }
.btn.secondary {
    background: #f0eaff;
    color: #7042e3;
}
.btn.danger {
    background: #fff0f0;
    color: #d33c50;
}
.btn.small { padding: 8px 12px; }
.panel {
    background: white;
    border-radius: 20px;
    padding: 25px;
    box-shadow: 0 4px 20px #19254b08;
    overflow-x: auto;
}
table {
    width: 100%;
    border-collapse: collapse;
    min-width: 680px;
}
th, td {
    padding: 16px 12px;
    border-bottom: 1px solid #f0f0f5;
    text-align: left;
    font-size: 13px;
}
th { color: #9499aa; font-size: 12px; }
.role {
    background: #f0eaff;
    color: #7042e3;
    padding: 7px 11px;
    border-radius: 20px;
    display: inline-block;
    text-transform: capitalize;
}
.actions { display: flex; gap: 8px; }
.alert {
    padding: 14px 18px;
    border-radius: 12px;
    margin-bottom: 20px;
    font-size: 14px;
}
.alert.success { background: #e9f8f0; color: #207b4c; }
.alert.error { background: #fff0f0; color: #bc354a; }
.modal-backdrop {
    position: fixed;
    inset: 0;
    background: #10162d99;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
    z-index: 100;
}
.modal-backdrop.open { display: flex; }
.modal {
    background: white;
    width: 100%;
    max-width: 500px;
    padding: 28px;
    border-radius: 20px;
    max-height: 90vh;
    overflow-y: auto;
}
.modal h2 { margin-top: 0; }
.field { margin-bottom: 17px; }
.field label {
    display: block;
    font-size: 13px;
    margin-bottom: 8px;
    font-weight: 600;
}
.field input, .field select {
    width: 100%;
    padding: 12px;
    border: 1px solid #dddfea;
    border-radius: 10px;
    font-size: 14px;
}
.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 22px;
}
@media(max-width: 750px) {
    .layout { display: block; }
    .sidebar { width: 100%; padding: 15px; }
    .logo { margin-bottom: 15px; }
    .menu-label { display: none; }
    .nav-link { display: inline-block; margin: 3px; }
    .main { padding: 20px; }
    .topbar { align-items: flex-start; flex-direction: column; }
}
</style>
</head>

<body>
<div class="layout">

<aside class="sidebar">
    <div class="logo">✦ EVENT<span>TIX</span></div>
    <div class="menu-label">MAIN MENU</div>
    <a class="nav-link" href="admin.php">◈ Dashboard</a>
    <a class="nav-link active" href="manage_users.php">♙ Manage Users</a>
    <a class="nav-link" href="manage_events.php">◇ Manage Events</a>
    <a class="nav-link" href="manage_venues.php">▣ Manage Venues</a>
    <a class="nav-link" href="manage_bookings.php">▤ Manage Bookings</a>
    <div class="menu-label">ACCOUNT</div>
    <a class="nav-link" href="../logout.php">↪ Logout</a>
</aside>

<main class="main">

    <div class="topbar">
        <div>
            <h1>Manage Users</h1>
            <p class="subtitle">View and manage registered EventTix users.</p>
        </div>
        <button class="btn" type="button" onclick="openCreate()">+ Add User</button>
    </div>

    <?php if ($notice !== ''): ?>
        <div class="alert <?= e($noticeType) ?>">
            <?= e($notice) ?>
        </div>
    <?php endif; ?>

    <section class="panel">
        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td>#<?= e($user['user_id']) ?></td>
                    <td><?= e($user['full_name']) ?></td>
                    <td><?= e($user['email']) ?></td>
                    <td><span class="role"><?= e($user['role']) ?></span></td>
                    <td>
                        <div class="actions">
                            <button
                                class="btn secondary small"
                                type="button"
                                onclick="openEdit(this)"
                                data-id="<?= e($user['user_id']) ?>"
                                data-name="<?= e($user['full_name']) ?>"
                                data-email="<?= e($user['email']) ?>"
                                data-role="<?= e($user['role']) ?>"
                            >Edit</button>

                            <form method="post" onsubmit="return confirm('Delete this user?');">
                                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="user_id" value="<?= e($user['user_id']) ?>">
                                <button class="btn danger small" type="submit">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>

                <?php if (empty($users)): ?>
                <tr>
                    <td colspan="5">No users found or API data unavailable.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>
</main>
</div>

<div class="modal-backdrop" id="userModal">
    <div class="modal">
        <h2 id="modalTitle">Add User</h2>

        <form method="post" id="userForm">
            <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
            <input type="hidden" name="action" id="formAction" value="create">
            <input type="hidden" name="user_id" id="formUserId">

            <div class="field">
                <label for="fullName">Full Name</label>
                <input id="fullName" name="full_name" required maxlength="150">
            </div>

            <div class="field">
                <label for="email">Email Address</label>
                <input id="email" name="email" type="email" required maxlength="255">
            </div>

            <div class="field">
                <label for="role">User Role</label>
                <select id="role" name="role" required>
                    <option value="admin">Admin</option>
                    <option value="organiser">Organiser</option>
                    <option value="customer">Customer</option>
                </select>
            </div>

            <div class="field">
                <label for="password" id="passwordLabel">Password</label>
                <input id="password" name="password" type="password" minlength="8" maxlength="72">
                <small id="passwordHint"></small>
            </div>

            <div class="modal-actions">
                <button class="btn secondary" type="button" onclick="closeModal()">Cancel</button>
                <button class="btn" type="submit">Save User</button>
            </div>
        </form>
    </div>
</div>

<script>
const modal = document.getElementById('userModal');

function openCreate() {
    document.getElementById('modalTitle').textContent = 'Add New User';
    document.getElementById('formAction').value = 'create';
    document.getElementById('userForm').reset();
    document.getElementById('formUserId').value = '';
    document.getElementById('password').required = true;
    document.getElementById('passwordLabel').textContent = 'Password';
    document.getElementById('passwordHint').textContent = 'Minimum 8 characters.';
    modal.classList.add('open');
}

function openEdit(button) {
    document.getElementById('modalTitle').textContent = 'Edit User';
    document.getElementById('formAction').value = 'update';
    document.getElementById('formUserId').value = button.dataset.id;
    document.getElementById('fullName').value = button.dataset.name;
    document.getElementById('email').value = button.dataset.email;
    document.getElementById('role').value = button.dataset.role;
    document.getElementById('password').value = '';
    document.getElementById('password').required = false;
    document.getElementById('passwordLabel').textContent = 'New Password (Optional)';
    document.getElementById('passwordHint').textContent = 'Leave blank to keep the current password.';
    modal.classList.add('open');
}

function closeModal() {
    modal.classList.remove('open');
}

modal.addEventListener('click', function(event) {
    if (event.target === modal) {
        closeModal();
    }
});
</script>

</body>
</html>
