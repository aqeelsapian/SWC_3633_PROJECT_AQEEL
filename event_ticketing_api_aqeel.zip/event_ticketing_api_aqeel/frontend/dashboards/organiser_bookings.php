<?php
$requiredRole = 'organiser';
require __DIR__ . '/../includes/auth_guard.php';
$token = $_SESSION['access_token'];
$name = $_SESSION['full_name'] ?? 'Organiser';
$base = 'http://localhost/event_ticketing_api/api/';
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function apiGet($endpoint, $token) {
    global $base;
    $ch = curl_init($base . $endpoint);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token,'Accept: application/json'], CURLOPT_TIMEOUT=>15, CURLOPT_FOLLOWLOCATION=>false]);
    $raw = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $data = is_string($raw) ? json_decode($raw,true) : null;
    return ['status'=>$status,'data'=>is_array($data)?$data:['success'=>false,'message'=>$error ?: 'Invalid API response']];
}
// The bookings API enforces organiser ownership on the server.
// Do not fetch bookings as an admin or filter other organisers' bookings in the browser.
$result = apiGet('bookings.php', $token);
$bookings = $result['data']['data'] ?? [];
if (!is_array($bookings)) $bookings=[];
$error = $result['status'] === 200 ? '' : ($result['data']['message'] ?? 'Unable to load bookings');
$confirmed=0; $cancelled=0; $tickets=0; $revenue=0;
foreach ($bookings as $b) {
    $status=strtolower((string)($b['booking_status'] ?? ''));
    if ($status==='confirmed') { $confirmed++; $tickets+=(int)($b['quantity'] ?? 0); $revenue+=(float)($b['total_price'] ?? 0); }
    elseif ($status==='cancelled') $cancelled++;
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Event Bookings | EventTix</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;color:#18213d;font-family:Arial,sans-serif}.layout{display:flex;min-height:100vh}.sidebar{width:250px;flex-shrink:0;background:#fff;border-right:1px solid #e9eaf2;padding:30px 18px}.logo{font-size:23px;font-weight:800;margin:0 0 44px 14px}.logo span{color:#8758f7}.label{color:#9a9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav{display:block;padding:14px 16px;border-radius:12px;margin-bottom:7px;text-decoration:none;color:#65708b;font-size:14px}.nav:hover,.nav.active{background:#f0eaff;color:#7144e8;font-weight:bold}.main{flex:1;min-width:0;padding:35px 45px}.top{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:26px}h1{margin:0 0 8px;font-size:29px}.sub{color:#8b91a4;margin:0}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:17px;margin-bottom:23px}.stat{background:white;border-radius:17px;padding:23px;box-shadow:0 4px 20px #19254b08}.stat .num{font-size:27px;font-weight:800;margin-top:10px;color:#7144e8}.stat .lbl{font-size:13px;color:#8790a6}.panel{background:#fff;border-radius:20px;padding:25px;overflow-x:auto;box-shadow:0 4px 20px #19254b08}.toolbar{display:flex;gap:12px;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap}.toolbar h2{margin:0;font-size:18px}.filters{display:flex;gap:10px;flex-wrap:wrap}.filters input,.filters select{padding:11px 13px;border:1px solid #e0e2ec;border-radius:10px;font-size:13px;background:white;min-width:150px}.filters input{min-width:240px}.alert{padding:14px 18px;border-radius:12px;margin-bottom:20px;background:#fff0f0;color:#bc354a}table{width:100%;border-collapse:collapse;min-width:960px}th,td{text-align:left;padding:15px 12px;border-bottom:1px solid #f0f0f5;font-size:13px}th{color:#9499aa;font-size:12px}.pill{border-radius:18px;padding:7px 11px;display:inline-block;font-weight:600;font-size:12px}.pill.confirmed{background:#e9f8f0;color:#207b4c}.pill.cancelled{background:#fff0f0;color:#c34554}.pill.other{background:#f0eaff;color:#7042e3}.empty{color:#8b91a4;text-align:center;padding:35px 0}.note{color:#8b91a4;font-size:12px;margin:16px 0 0}@media(max-width:1050px){.stats{grid-template-columns:repeat(2,1fr)}}@media(max-width:750px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.label{display:none}.nav{display:inline-block;margin:3px}.main{padding:20px}.top{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.filters input{min-width:0;width:100%}}
</style></head><body><div class="layout"><aside class="sidebar"><div class="logo">✦ EVENT<span>TIX</span></div><div class="label">ORGANISER MENU</div><a class="nav" href="organiser.php">◈ Dashboard</a><a class="nav" href="organiser_events.php">◇ My Events</a><a class="nav" href="organiser_schedules.php">▣ Event Schedules</a><a class="nav active" href="organiser_bookings.php">▤ Event Bookings</a><div class="label">ACCOUNT</div><a class="nav" href="../logout.php">↪ Logout</a></aside><main class="main"><div class="top"><div><h1>Event Bookings</h1><p class="sub">View ticket bookings for your events.</p></div></div>
<?php if($error): ?><div class="alert"><?= h($error) ?></div><?php endif; ?>
<div class="stats"><div class="stat"><div class="lbl">Total Bookings</div><div class="num"><?= count($bookings) ?></div></div><div class="stat"><div class="lbl">Confirmed Bookings</div><div class="num"><?= $confirmed ?></div></div><div class="stat"><div class="lbl">Tickets Sold</div><div class="num"><?= $tickets ?></div></div><div class="stat"><div class="lbl">Confirmed Booking Value</div><div class="num">RM <?= number_format($revenue,2) ?></div></div></div>
<section class="panel"><div class="toolbar"><h2>Booking Records</h2><div class="filters"><input id="search" type="search" placeholder="Search customer or event..." aria-label="Search bookings"><select id="statusFilter" aria-label="Filter booking status"><option value="">All Statuses</option><option value="confirmed">Confirmed</option><option value="cancelled">Cancelled</option></select></div></div><table><thead><tr><th>Booking ID</th><th>Customer</th><th>Event</th><th>Schedule Date &amp; Time</th><th>Quantity</th><th>Total Price</th><th>Status</th><th>Booked At</th></tr></thead><tbody id="bookingRows">
<?php foreach($bookings as $b): $status=strtolower((string)($b['booking_status'] ?? '')); $pill=in_array($status,['confirmed','cancelled'],true)?$status:'other'; ?><tr data-status="<?= h($status) ?>" data-search="<?= h(strtolower(($b['customer_name'] ?? '').' '.($b['event_title'] ?? '').' '.($b['booking_id'] ?? ''))) ?>"><td>#<?= h($b['booking_id'] ?? '') ?></td><td><?= h($b['customer_name'] ?? '—') ?></td><td><?= h($b['event_title'] ?? '—') ?></td><td><?= h($b['start_time'] ?? '—') ?></td><td><?= h($b['quantity'] ?? '0') ?></td><td>RM <?= number_format((float)($b['total_price'] ?? 0),2) ?></td><td><span class="pill <?= h($pill) ?>"><?= h(ucfirst($status ?: 'Unknown')) ?></span></td><td><?= h($b['booked_at'] ?? '—') ?></td></tr><?php endforeach; ?>
<?php if(!$bookings): ?><tr id="emptyInitial"><td colspan="8" class="empty"><?= $error ? 'Bookings could not be loaded.' : 'No bookings for your events yet.' ?></td></tr><?php endif; ?><tr id="noMatch" hidden><td colspan="8" class="empty">No matching bookings found.</td></tr></tbody></table><p class="note">Read-only view. Only bookings belonging to your events are returned by the API. Confirmed booking value is not necessarily collected revenue.</p></section></main></div>
<script>
const search=document.getElementById('search'),statusFilter=document.getElementById('statusFilter'),rows=[...document.querySelectorAll('#bookingRows tr[data-status]')],noMatch=document.getElementById('noMatch');
function filterRows(){const q=search.value.toLowerCase().trim(),s=statusFilter.value;let shown=0;rows.forEach(row=>{const visible=(!s||row.dataset.status===s)&&row.dataset.search.includes(q);row.hidden=!visible;if(visible)shown++;});noMatch.hidden=shown>0||rows.length===0;}
search.addEventListener('input',filterRows);statusFilter.addEventListener('change',filterRows);
</script></body></html>
