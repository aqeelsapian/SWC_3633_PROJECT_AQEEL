<?php
$requiredRole = 'admin';
require __DIR__ . '/../includes/auth_guard.php';
$token = $_SESSION['access_token'];
$apiUrl = 'http://localhost/event_ticketing_api/api/venues.php';
function esc($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function venueApi(string $method, string $url, string $token, ?array $payload = null): array {
    if (!function_exists('curl_init')) return ['status'=>0,'body'=>['message'=>'PHP cURL extension is not enabled']];
    $ch = curl_init($url);
    $headers = ['Authorization: Bearer '.$token, 'Accept: application/json'];
    if ($payload !== null) $headers[] = 'Content-Type: application/json';
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_CUSTOMREQUEST=>$method, CURLOPT_HTTPHEADER=>$headers, CURLOPT_TIMEOUT=>12, CURLOPT_FOLLOWLOCATION=>false]);
    if ($payload !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    $raw = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $body = is_string($raw) ? json_decode($raw, true) : null;
    return ['status'=>$status,'body'=>is_array($body)?$body:['message'=>$error ?: 'Unexpected API response']];
}
if (empty($_SESSION['venues_csrf'])) $_SESSION['venues_csrf'] = bin2hex(random_bytes(32));
$notice = ''; $noticeType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['venues_csrf'], (string)($_POST['csrf_token'] ?? ''))) { http_response_code(403); exit('Invalid form token'); }
    $action = (string)($_POST['action'] ?? '');
    $id = filter_var($_POST['venue_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
    if ($action === 'create' || $action === 'update') {
        $capacity = filter_var($_POST['capacity'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
        $payload = ['venue_name'=>trim((string)($_POST['venue_name']??'')), 'location'=>trim((string)($_POST['location']??'')), 'capacity'=>$capacity, 'description'=>trim((string)($_POST['description']??''))];
        if ($payload['venue_name']==='' || $payload['location']==='' || $capacity===false) $result = ['status'=>400,'body'=>['message'=>'Venue name, location and positive capacity are required']];
        elseif ($action==='update' && $id===false) $result = ['status'=>400,'body'=>['message'=>'Invalid venue ID']];
        else $result = venueApi($action==='create'?'POST':'PUT', $apiUrl.($action==='update'?'?id='.$id:''), $token, $payload);
    } elseif ($action==='delete') {
        $result = $id===false ? ['status'=>400,'body'=>['message'=>'Invalid venue ID']] : venueApi('DELETE',$apiUrl.'?id='.$id,$token);
    } else $result=['status'=>400,'body'=>['message'=>'Invalid action']];
    $notice = (string)($result['body']['message'] ?? 'Request completed');
    $noticeType = !empty($result['body']['success']) ? 'success' : 'error';
    if ($result['status']===401) $notice='Login expired. Please log in again.';
}
$listing = venueApi('GET',$apiUrl,$token);
$venues = $listing['body']['data'] ?? [];
if (!is_array($venues)) $venues=[];
if ($listing['status']!==200) { $notice=(string)($listing['body']['message']??'Unable to load venues'); $noticeType='error'; }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Manage Venues | EventTix</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;color:#18213d;font-family:Arial,sans-serif}.layout{display:flex;min-height:100vh}.sidebar{width:250px;flex-shrink:0;background:#fff;border-right:1px solid #e9eaf2;padding:30px 18px}.logo{font-size:23px;font-weight:800;margin:0 0 45px 14px}.logo span{color:#8758f7}.menu-label{color:#9a9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav-link{display:block;text-decoration:none;color:#65708b;padding:14px 16px;border-radius:12px;margin-bottom:7px;font-size:14px}.nav-link:hover,.nav-link.active{background:#f0eaff;color:#7144e8;font-weight:bold}.main{flex:1;padding:35px 45px;min-width:0}.topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:28px}h1{font-size:29px;margin:0 0 8px}.subtitle{color:#8b91a4;margin:0}.btn{border:0;background:#794ce9;color:#fff;border-radius:11px;padding:12px 18px;font-size:13px;font-weight:600;cursor:pointer}.btn:hover{background:#643bd0}.btn.secondary{background:#f0eaff;color:#7042e3}.btn.danger{background:#fff0f0;color:#d33c50}.btn.small{padding:8px 12px}.panel{background:#fff;border-radius:20px;padding:25px;box-shadow:0 4px 20px #19254b08;overflow-x:auto}table{width:100%;border-collapse:collapse;min-width:750px}th,td{text-align:left;border-bottom:1px solid #f0f0f5;padding:16px 12px;font-size:13px}th{color:#9499aa;font-size:12px}.actions{display:flex;gap:8px}.alert{padding:14px 18px;border-radius:12px;margin-bottom:20px;font-size:14px}.alert.success{background:#e9f8f0;color:#207b4c}.alert.error{background:#fff0f0;color:#bc354a}.modal-backdrop{position:fixed;inset:0;background:#10162d99;display:none;align-items:center;justify-content:center;padding:20px;z-index:100}.modal-backdrop.open{display:flex}.modal{background:#fff;width:100%;max-width:510px;padding:28px;border-radius:20px;max-height:90vh;overflow:auto}.modal h2{margin-top:0}.field{margin-bottom:17px}.field label{display:block;font-size:13px;margin-bottom:8px;font-weight:600}.field input,.field textarea{width:100%;padding:12px;border:1px solid #dddfea;border-radius:10px;font:14px Arial,sans-serif}.field textarea{min-height:90px;resize:vertical}.modal-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:22px}.search{width:100%;max-width:300px;padding:12px;border:1px solid #dddfea;border-radius:11px;margin-bottom:18px}@media(max-width:750px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.menu-label{display:none}.nav-link{display:inline-block;margin:3px}.main{padding:20px}.topbar{align-items:flex-start;flex-direction:column}}
</style></head><body><div class="layout"><aside class="sidebar"><div class="logo">✦ EVENT<span>TIX</span></div><div class="menu-label">MAIN MENU</div><a class="nav-link" href="admin.php">◈ Dashboard</a><a class="nav-link" href="manage_users.php">♙ Manage Users</a><a class="nav-link" href="manage_events.php">◇ Manage Events</a><a class="nav-link active" href="manage_venues.php">▣ Manage Venues</a><a class="nav-link" href="manage_bookings.php">▤ Manage Bookings</a><div class="menu-label">ACCOUNT</div><a class="nav-link" href="../logout.php">↪ Logout</a></aside><main class="main"><div class="topbar"><div><h1>Manage Venues</h1><p class="subtitle">View and manage EventTix venues and capacities.</p></div><button type="button" class="btn" onclick="openCreate()">+ Add Venue</button></div>
<?php if($notice!==''): ?><div class="alert <?=esc($noticeType)?>"><?=esc($notice)?></div><?php endif; ?>
<section class="panel"><input class="search" id="search" type="search" placeholder="Search venues or locations..." aria-label="Search venues"><table><thead><tr><th>Venue ID</th><th>Venue Name</th><th>Location</th><th>Capacity</th><th>Description</th><th>Actions</th></tr></thead><tbody id="venueRows">
<?php foreach($venues as $venue): ?><tr><td>#<?=esc($venue['venue_id']??'')?></td><td><?=esc($venue['venue_name']??'')?></td><td><?=esc($venue['location']??'')?></td><td><?=esc($venue['capacity']??'')?></td><td><?=esc($venue['description']??'')?></td><td><div class="actions"><button type="button" class="btn secondary small" onclick="openEdit(this)" data-id="<?=esc($venue['venue_id']??'')?>" data-name="<?=esc($venue['venue_name']??'')?>" data-location="<?=esc($venue['location']??'')?>" data-capacity="<?=esc($venue['capacity']??'')?>" data-description="<?=esc($venue['description']??'')?>">Edit</button><form method="post" onsubmit="return confirm('Delete this venue? Venues linked to events cannot be deleted.');"><input type="hidden" name="csrf_token" value="<?=esc($_SESSION['venues_csrf'])?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="venue_id" value="<?=esc($venue['venue_id']??'')?>"><button type="submit" class="btn danger small">Delete</button></form></div></td></tr><?php endforeach; ?>
<?php if(empty($venues)): ?><tr><td colspan="6">No venues found or API data unavailable.</td></tr><?php endif; ?></tbody></table></section></main></div>
<div class="modal-backdrop" id="venueModal"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><h2 id="modalTitle">Add Venue</h2><form method="post" id="venueForm"><input type="hidden" name="csrf_token" value="<?=esc($_SESSION['venues_csrf'])?>"><input type="hidden" name="action" id="formAction" value="create"><input type="hidden" name="venue_id" id="venueId"><div class="field"><label for="venueName">Venue Name</label><input id="venueName" name="venue_name" required maxlength="255"></div><div class="field"><label for="venueLocation">Location</label><input id="venueLocation" name="location" required maxlength="255"></div><div class="field"><label for="venueCapacity">Capacity</label><input id="venueCapacity" name="capacity" type="number" min="1" step="1" required></div><div class="field"><label for="venueDescription">Description</label><textarea id="venueDescription" name="description"></textarea></div><div class="modal-actions"><button type="button" class="btn secondary" onclick="closeModal()">Cancel</button><button type="submit" class="btn">Save Venue</button></div></form></div></div>
<script>
const modal=document.getElementById('venueModal');
function openCreate(){document.getElementById('venueForm').reset();document.getElementById('modalTitle').textContent='Add New Venue';document.getElementById('formAction').value='create';document.getElementById('venueId').value='';modal.classList.add('open');document.getElementById('venueName').focus()}
function openEdit(button){document.getElementById('modalTitle').textContent='Edit Venue';document.getElementById('formAction').value='update';document.getElementById('venueId').value=button.dataset.id;document.getElementById('venueName').value=button.dataset.name;document.getElementById('venueLocation').value=button.dataset.location;document.getElementById('venueCapacity').value=button.dataset.capacity;document.getElementById('venueDescription').value=button.dataset.description;modal.classList.add('open');document.getElementById('venueName').focus()}
function closeModal(){modal.classList.remove('open')}
modal.addEventListener('click',e=>{if(e.target===modal)closeModal()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
document.getElementById('search').addEventListener('input',function(){const q=this.value.toLowerCase();document.querySelectorAll('#venueRows tr').forEach(row=>{row.style.display=row.textContent.toLowerCase().includes(q)?'':'none'})});
</script></body></html>
