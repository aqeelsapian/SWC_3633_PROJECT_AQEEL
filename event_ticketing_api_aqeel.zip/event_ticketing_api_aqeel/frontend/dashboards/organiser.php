<?php
$requiredRole = 'organiser';
require __DIR__ . '/../includes/auth_guard.php';

$name = htmlspecialchars((string)($_SESSION['full_name'] ?? 'Organiser'), ENT_QUOTES, 'UTF-8');
$token = (string)$_SESSION['access_token'];
$apiBase = 'http://localhost/event_ticketing_api/api/';

function organiserApi(string $endpoint, string $token): array {
    global $apiBase;
    $ch = curl_init($apiBase . $endpoint);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Accept: application/json'],
        CURLOPT_TIMEOUT => 12,
        CURLOPT_FOLLOWLOCATION => false
    ]);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $body = is_string($raw) ? json_decode($raw, true) : null;
    return ['ok' => $code === 200 && is_array($body) && ($body['success'] ?? false), 'body' => is_array($body) ? $body : [], 'error' => $error];
}
function esc($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Organiser identity comes from the verified JWT claims, not a browser-supplied ID.
// The API already filters bookings by organiser; event records are filtered below.
$jwtParts = explode('.', $token);
$claims = [];
if (count($jwtParts) === 3) {
    $payload = base64_decode(strtr($jwtParts[1], '-_', '+/'), true);
    $decoded = $payload !== false ? json_decode($payload, true) : null;
    if (is_array($decoded)) $claims = $decoded;
}
$organiserId = (int)($_SESSION['user_id'] ?? $claims['user_id'] ?? $claims['data']['user_id'] ?? 0);

$events = [];
$eventError = false;
for ($page = 1; $page <= 30; $page++) {
    $result = organiserApi('events.php?page=' . $page . '&limit=100', $token);
    if (!$result['ok']) { $eventError = true; break; }
    $batch = $result['body']['data'] ?? [];
    if (!is_array($batch)) { $eventError = true; break; }
    foreach ($batch as $event) {
        if ($organiserId > 0 && (int)($event['organiser_id'] ?? 0) === $organiserId) $events[] = $event;
    }
    $totalPages = (int)($result['body']['total_pages'] ?? 1);
    if ($page >= $totalPages) break;
}
$bookingsResult = organiserApi('bookings.php', $token);
$bookings = $bookingsResult['body']['data'] ?? [];
if (!is_array($bookings)) $bookings = [];
$confirmed = 0;
foreach ($bookings as $booking) if (($booking['booking_status'] ?? '') === 'confirmed') $confirmed++;
$published = 0;
foreach ($events as $event) if (($event['status'] ?? '') === 'published') $published++;
$recent = array_slice(array_reverse($events), 0, 6);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Organiser Dashboard | EventTix</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;color:#20243d;font-family:Arial,sans-serif}.layout{display:flex;min-height:100vh}.sidebar{width:250px;flex-shrink:0;background:white;border-right:1px solid #ebebf3;padding:30px 18px}.logo{font-size:23px;font-weight:800;margin:0 0 43px 14px;color:#20243d}.logo span{color:#8758f7}.label{color:#9b9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav{display:block;text-decoration:none;color:#65708b;padding:14px 16px;border-radius:12px;margin-bottom:7px;font-size:14px}.nav:hover,.nav.active{background:#f0eaff;color:#7144e8;font-weight:700}.main{flex:1;min-width:0;padding:35px 45px}.top{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:30px}.top h1{font-size:29px;margin:0 0 8px}.muted{color:#8991a4;margin:0}.profile{background:white;border-radius:14px;padding:13px 18px;font-size:13px}.profile strong{color:#7144e8}.hero{background:linear-gradient(110deg,#6741e8,#a276ff);padding:33px;border-radius:22px;color:white;margin-bottom:28px}.hero h2{font-size:25px;margin:0 0 10px}.hero p{margin:0;color:#f1eaff}.cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px;margin-bottom:28px}.card,.panel{background:white;border-radius:18px;padding:25px;box-shadow:0 4px 20px #19254b08}.icon{width:44px;height:44px;border-radius:12px;background:#f0eaff;color:#7549e7;display:grid;place-items:center;font-size:21px;margin-bottom:17px}.card p{color:#8991a4;font-size:13px;margin:0 0 10px}.card h3{font-size:30px;margin:0}.panel{overflow-x:auto}.panel h2{font-size:19px;margin:0 0 20px}.table{width:100%;border-collapse:collapse;min-width:600px}.table th,.table td{padding:15px 12px;text-align:left;border-bottom:1px solid #f0f0f5;font-size:13px}.table th{color:#9a9eae;font-size:12px}.pill{display:inline-block;background:#f0eaff;color:#7144e8;border-radius:20px;padding:7px 11px;text-transform:capitalize}.warning{background:#fff4e5;color:#9a6115;padding:12px 16px;border-radius:12px;margin-bottom:16px;font-size:13px}.empty{color:#8991a4;font-size:14px}.quick{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:24px}.quick a{background:white;color:#7042e3;text-decoration:none;padding:12px 16px;border-radius:12px;font-size:13px;font-weight:bold;border:1px solid #e9e1ff}@media(max-width:900px){.cards{grid-template-columns:1fr}.main{padding:24px}}@media(max-width:650px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.label{display:none}.nav{display:inline-block;margin:3px}.top{flex-direction:column;align-items:flex-start}.main{padding:18px}}
</style>
</head>
<body><div class="layout">
<aside class="sidebar">
<div class="logo">✦ EVENT<span>TIX</span></div>
<div class="label">ORGANISER MENU</div>
<a class="nav active" href="organiser.php">◈ Dashboard</a>
<a class="nav" href="organiser_events.php">◇ My Events</a>
<a class="nav" href="organiser_schedules.php">▣ Event Schedules</a>
<a class="nav" href="organiser_bookings.php">▤ Event Bookings</a>
<div class="label">ACCOUNT</div>
<a class="nav" href="../logout.php">↪ Logout</a>
</aside>
<main class="main">
<header class="top"><div><h1>Organiser Dashboard</h1><p class="muted">Manage your events and track ticket bookings.</p></div><div class="profile">● <?= $name ?> · <strong>Organiser</strong></div></header>
<section class="hero"><h2>Welcome to EventTix ✨</h2><p>Keep your events organised and stay on top of your bookings.</p></section>
<?php if ($organiserId <= 0): ?><div class="warning">Unable to determine organiser ID from the login session. Check the JWT user_id claim before trusting event statistics.</div><?php endif; ?>
<?php if ($eventError || !$bookingsResult['ok']): ?><div class="warning">Some API data could not be loaded. Check your JWT session and backend API connection.</div><?php endif; ?>
<section class="cards">
<div class="card"><div class="icon">◇</div><p>My Events</p><h3><?= $organiserId > 0 ? count($events) : '—' ?></h3></div>
<div class="card"><div class="icon">✦</div><p>Published Events</p><h3><?= $organiserId > 0 ? $published : '—' ?></h3></div>
<div class="card"><div class="icon">▤</div><p>Confirmed Bookings</p><h3><?= $bookingsResult['ok'] ? $confirmed : '—' ?></h3></div>
</section>
<div class="quick"><a href="organiser_events.php">+ Manage My Events →</a><a href="organiser_schedules.php">Manage Schedules →</a><a href="organiser_bookings.php">View Bookings →</a></div>
<section class="panel"><h2>My Recent Events</h2>
<?php if (!$recent): ?><p class="empty">No events found for this organiser yet.</p>
<?php else: ?><table class="table"><thead><tr><th>Event ID</th><th>Event Name</th><th>Venue</th><th>Category</th><th>Status</th></tr></thead><tbody>
<?php foreach ($recent as $event): ?><tr><td>#<?= esc($event['event_id'] ?? '-') ?></td><td><?= esc($event['title'] ?? '-') ?></td><td><?= esc($event['venue_name'] ?? '-') ?></td><td><?= esc($event['category'] ?? '-') ?></td><td><span class="pill"><?= esc($event['status'] ?? '-') ?></span></td></tr><?php endforeach; ?>
</tbody></table><?php endif; ?>
</section>
</main></div></body></html>
