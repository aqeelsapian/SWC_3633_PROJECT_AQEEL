<?php
$requiredRole = 'organiser';
require __DIR__ . '/../includes/auth_guard.php';
$token = $_SESSION['access_token'];
$name = $_SESSION['full_name'] ?? 'Organiser';
$base = 'http://localhost/event_ticketing_api/api/';
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function requestApi($method, $endpoint, $token, $body = null) {
    global $base;
    $ch = curl_init($base . $endpoint);
    $headers = ['Authorization: Bearer ' . $token, 'Accept: application/json'];
    if ($body !== null) $headers[] = 'Content-Type: application/json';
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_CUSTOMREQUEST=>$method, CURLOPT_HTTPHEADER=>$headers, CURLOPT_TIMEOUT=>12, CURLOPT_FOLLOWLOCATION=>false]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    $raw = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    return ['status'=>$status, 'data'=>is_array($data)?$data:['success'=>false,'message'=>$error ?: 'Invalid API response']];
}
function ownEvents($token) {
    $all = []; $page=1;
    do {
        $r = requestApi('GET', 'events.php?page='.$page.'&limit=100', $token);
        if ($r['status'] !== 200) return ['error'=>$r['data']['message'] ?? 'Could not load events', 'items'=>[]];
        $rows = $r['data']['data'] ?? [];
        if (!is_array($rows)) break;
        foreach ($rows as $row) $all[]=$row;
        $pages = (int)($r['data']['total_pages'] ?? 1);
        $page++;
    } while ($page <= $pages && $page <= 100);
    return ['error'=>'','items'=>$all];
}
$eventsResult = ownEvents($token);
$myEvents=[];
// Backend does not offer a 'my events' filter; determine owner from signed-in user's JWT subject.
// The session might not contain user_id, so resolve it using the JWT payload only as a UI filter;
// API still verifies JWT signature and ownership on mutations.
$userId = (int)($_SESSION['user_id'] ?? 0);
if (!$userId) {
    $parts = explode('.', $token);
    if (count($parts) === 3) {
        $payload = strtr($parts[1], '-_', '+/');
        $payload .= str_repeat('=', (4-strlen($payload)%4)%4);
        $claims = json_decode(base64_decode($payload, true) ?: '', true);
        if (is_array($claims)) $userId = (int)($claims['user_id'] ?? $claims['data']['user_id'] ?? $claims['sub'] ?? 0);
    }
}
foreach ($eventsResult['items'] as $event) if ((int)($event['organiser_id'] ?? 0) === $userId) $myEvents[]=$event;
$eventIds = array_fill_keys(array_map(fn($e)=>(int)$e['event_id'], $myEvents), true);
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token']=bin2hex(random_bytes(32));
$notice=''; $noticeType='success';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) { http_response_code(403); exit('Invalid CSRF token'); }
    $action = $_POST['action'] ?? '';
    $id = filter_var($_POST['schedule_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
    $eventId = filter_var($_POST['event_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
    if ($action === 'delete') {
        $result = $id ? requestApi('DELETE', 'schedules.php?id='.$id, $token) : ['status'=>400,'data'=>['message'=>'Invalid schedule ID']];
    } elseif (in_array($action, ['create','update'], true)) {
        $start = trim($_POST['start_time'] ?? ''); $end = trim($_POST['end_time'] ?? '');
        $start = str_replace('T',' ', $start); $end = str_replace('T',' ', $end);
        if (strlen($start)===16) $start .= ':00';
        if (strlen($end)===16) $end .= ':00';
        $total = filter_var($_POST['total_tickets'] ?? null, FILTER_VALIDATE_INT);
        $available = filter_var($_POST['available_tickets'] ?? null, FILTER_VALIDATE_INT);
        $price = $_POST['ticket_price'] ?? '';
        if (!$eventId || !isset($eventIds[$eventId]) || !$total || $total<1 || $available===false || $available<0 || $available>$total || !is_numeric($price) || (float)$price<0 || strtotime($end) <= strtotime($start)) {
            $result=['status'=>400,'data'=>['message'=>'Check event ownership, date/time, ticket counts and price.']];
        } else {
            $body=['event_id'=>$eventId,'start_time'=>$start,'end_time'=>$end,'total_tickets'=>$total,'available_tickets'=>$available,'ticket_price'=>(float)$price];
            $result = $action==='create' ? requestApi('POST','schedules.php',$token,$body) : ($id ? requestApi('PUT','schedules.php?id='.$id,$token,$body) : ['status'=>400,'data'=>['message'=>'Invalid schedule ID']]);
        }
    } else $result=['status'=>400,'data'=>['message'=>'Invalid action']];
    $notice=$result['data']['message'] ?? 'Request completed';
    $noticeType=!empty($result['data']['success'])?'success':'error';
}
$schedulesResult=requestApi('GET','schedules.php',$token);
$allSchedules=$schedulesResult['data']['data'] ?? [];
$schedules=[];
if (is_array($allSchedules)) foreach ($allSchedules as $schedule) if (isset($eventIds[(int)($schedule['event_id'] ?? 0)])) $schedules[]=$schedule;
if ($eventsResult['error'] && !$notice) { $notice=$eventsResult['error']; $noticeType='error'; }
if ($schedulesResult['status'] !== 200 && !$notice) { $notice=$schedulesResult['data']['message'] ?? 'Could not load schedules'; $noticeType='error'; }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Event Schedules | EventTix</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;color:#18213d;font-family:Arial,sans-serif}.layout{display:flex;min-height:100vh}.sidebar{width:250px;flex-shrink:0;background:white;border-right:1px solid #e9eaf2;padding:30px 18px}.logo{font-size:23px;font-weight:800;margin:0 0 44px 14px}.logo span{color:#8758f7}.label{color:#9a9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav{display:block;padding:14px 16px;border-radius:12px;margin-bottom:7px;text-decoration:none;color:#65708b;font-size:14px}.nav:hover,.nav.active{background:#f0eaff;color:#7144e8;font-weight:bold}.main{flex:1;min-width:0;padding:35px 45px}.top{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:26px}h1{margin:0 0 8px;font-size:29px}.sub{color:#8b91a4;margin:0}.btn{background:#794ce9;color:#fff;border:0;border-radius:11px;padding:12px 17px;cursor:pointer;font-weight:600}.btn:hover{background:#6338d3}.btn.secondary{background:#f0eaff;color:#7042e3}.btn.danger{background:#fff0f0;color:#d33c50}.btn.small{padding:8px 11px}.panel{background:#fff;border-radius:20px;padding:25px;overflow-x:auto;box-shadow:0 4px 20px #19254b08}.alert{padding:14px 18px;border-radius:12px;margin-bottom:20px}.alert.success{background:#e9f8f0;color:#207b4c}.alert.error{background:#fff0f0;color:#bc354a}table{width:100%;border-collapse:collapse;min-width:840px}th,td{text-align:left;padding:15px 12px;border-bottom:1px solid #f0f0f5;font-size:13px}th{color:#9499aa;font-size:12px}.actions{display:flex;gap:8px}.actions form{margin:0}.pill{background:#f0eaff;color:#7042e3;border-radius:18px;padding:6px 10px;display:inline-block}.modal-wrap{position:fixed;inset:0;background:#10162d99;display:none;align-items:center;justify-content:center;padding:18px;z-index:5}.modal-wrap.open{display:flex}.modal{background:white;border-radius:20px;padding:27px;max-width:560px;width:100%;max-height:92vh;overflow:auto}.modal h2{margin-top:0}.field{margin:0 0 15px}.field label{display:block;margin-bottom:7px;font-size:13px;font-weight:bold}.field input,.field select{width:100%;padding:12px;border:1px solid #dddfea;border-radius:10px;font-size:14px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.modal-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:22px}.hint{font-size:12px;color:#81889a;line-height:1.5}.empty{color:#8b91a4;padding:20px 0}@media(max-width:750px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.label{display:none}.nav{display:inline-block;margin:3px}.main{padding:20px}.top{align-items:flex-start;flex-direction:column}.grid{grid-template-columns:1fr}}
</style></head><body><div class="layout"><aside class="sidebar"><div class="logo">✦ EVENT<span>TIX</span></div><div class="label">ORGANISER MENU</div><a class="nav" href="organiser.php">◈ Dashboard</a><a class="nav" href="organiser_events.php">◇ My Events</a><a class="nav active" href="organiser_schedules.php">▣ Event Schedules</a><a class="nav" href="organiser_bookings.php">▤ Event Bookings</a><div class="label">ACCOUNT</div><a class="nav" href="../logout.php">↪ Logout</a></aside><main class="main"><div class="top"><div><h1>Event Schedules</h1><p class="sub">Manage dates, ticket capacity and prices for your events.</p></div><button class="btn" onclick="openCreate()" <?= empty($myEvents)?'disabled':'' ?>>+ Add Schedule</button></div>
<?php if($notice): ?><div class="alert <?= h($noticeType) ?>"><?= h($notice) ?></div><?php endif; ?>
<section class="panel"><table><thead><tr><th>ID</th><th>Event</th><th>Start</th><th>End</th><th>Total Tickets</th><th>Available</th><th>Price</th><th>Actions</th></tr></thead><tbody>
<?php foreach($schedules as $s): ?><tr><td>#<?= h($s['schedule_id'] ?? '') ?></td><td><?= h($s['event_title'] ?? '') ?></td><td><?= h($s['start_time'] ?? '') ?></td><td><?= h($s['end_time'] ?? '') ?></td><td><?= h($s['total_tickets'] ?? '') ?></td><td><span class="pill"><?= h($s['available_tickets'] ?? '') ?></span></td><td>RM <?= number_format((float)($s['ticket_price'] ?? 0),2) ?></td><td><div class="actions"><button type="button" class="btn secondary small" onclick="openEdit(this)" data-id="<?= h($s['schedule_id'] ?? '') ?>" data-event="<?= h($s['event_id'] ?? '') ?>" data-start="<?= h($s['start_time'] ?? '') ?>" data-end="<?= h($s['end_time'] ?? '') ?>" data-total="<?= h($s['total_tickets'] ?? '') ?>" data-available="<?= h($s['available_tickets'] ?? '') ?>" data-price="<?= h($s['ticket_price'] ?? '') ?>">Edit</button><form method="post" onsubmit="return confirm('Delete this schedule? Schedules with bookings cannot be deleted.');"><input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="schedule_id" value="<?= h($s['schedule_id'] ?? '') ?>"><button class="btn danger small">Delete</button></form></div></td></tr><?php endforeach; ?>
<?php if(!$schedules): ?><tr><td colspan="8" class="empty">No schedules for your events yet.</td></tr><?php endif; ?></tbody></table></section></main></div>
<div class="modal-wrap" id="modal"><div class="modal"><h2 id="modalTitle">Add Schedule</h2><form method="post" id="scheduleForm"><input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>"><input type="hidden" name="action" id="action" value="create"><input type="hidden" name="schedule_id" id="scheduleId"><div class="field"><label for="eventId">Your Event</label><select id="eventId" name="event_id" required><?php foreach($myEvents as $e): ?><option value="<?= h($e['event_id']) ?>"><?= h($e['title']) ?> (#<?= h($e['event_id']) ?>)</option><?php endforeach; ?></select></div><div class="grid"><div class="field"><label for="start">Start Date &amp; Time</label><input type="datetime-local" id="start" name="start_time" required></div><div class="field"><label for="end">End Date &amp; Time</label><input type="datetime-local" id="end" name="end_time" required></div></div><div class="grid"><div class="field"><label for="total">Total Tickets</label><input type="number" id="total" name="total_tickets" min="1" required></div><div class="field"><label for="available">Available Tickets</label><input type="number" id="available" name="available_tickets" min="0" required></div></div><div class="field"><label for="price">Ticket Price (RM)</label><input type="number" id="price" name="ticket_price" min="0" step="0.01" required></div><p class="hint">When creating a schedule, available tickets should normally equal total tickets. If bookings exist, keep the remaining stock consistent with confirmed bookings.</p><div class="modal-actions"><button class="btn secondary" type="button" onclick="closeModal()">Cancel</button><button class="btn" type="submit">Save Schedule</button></div></form></div></div>
<script>
const modal=document.getElementById('modal');const form=document.getElementById('scheduleForm');
function openCreate(){form.reset();document.getElementById('action').value='create';document.getElementById('scheduleId').value='';document.getElementById('modalTitle').textContent='Add Schedule';modal.classList.add('open');}
function openEdit(b){form.reset();document.getElementById('action').value='update';document.getElementById('scheduleId').value=b.dataset.id;document.getElementById('eventId').value=b.dataset.event;document.getElementById('start').value=b.dataset.start.replace(' ','T').slice(0,16);document.getElementById('end').value=b.dataset.end.replace(' ','T').slice(0,16);document.getElementById('total').value=b.dataset.total;document.getElementById('available').value=b.dataset.available;document.getElementById('price').value=b.dataset.price;document.getElementById('modalTitle').textContent='Edit Schedule';modal.classList.add('open');}
function closeModal(){modal.classList.remove('open')}modal.addEventListener('click',e=>{if(e.target===modal)closeModal()});
</script></body></html>
