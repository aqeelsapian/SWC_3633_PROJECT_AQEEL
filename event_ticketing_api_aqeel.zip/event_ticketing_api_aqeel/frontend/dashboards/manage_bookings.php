<?php
$requiredRole = 'admin';
require __DIR__ . '/../includes/auth_guard.php';

$token = $_SESSION['access_token'];
$base = 'http://localhost/event_ticketing_api/api/';

function apiCall(string $method, string $endpoint, string $token, ?array $payload = null): array {
    global $base;
    $ch = curl_init($base . $endpoint);
    $headers = ['Authorization: Bearer ' . $token, 'Accept: application/json'];
    if ($payload !== null) $headers[] = 'Content-Type: application/json';
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers, CURLOPT_TIMEOUT => 12, CURLOPT_FOLLOWLOCATION => false]);
    if ($payload !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    $raw = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $json = is_string($raw) ? json_decode($raw, true) : null;
    return ['status' => $status, 'body' => is_array($json) ? $json :
        ['success' => false, 'message' => $error ?: 'Invalid API response']];
}
function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function validId($value): ?int {
    $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    return $id === false || $id === null ? null : $id;
}
if (empty($_SESSION['bookings_csrf'])) $_SESSION['bookings_csrf'] = bin2hex(random_bytes(32));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['bookings_csrf'], (string)($_POST['csrf'] ?? ''))) {
        http_response_code(403); exit('Invalid CSRF token');
    }
    $action = $_POST['action'] ?? '';
    $id = validId($_POST['booking_id'] ?? null);
    $result = ['status' => 400, 'body' => ['success' => false, 'message' => 'Invalid form action']];
    if ($action === 'create') {
        $customer = validId($_POST['user_id'] ?? null);
        $schedule = validId($_POST['schedule_id'] ?? null);
        $quantity = validId($_POST['quantity'] ?? null);
        if ($customer && $schedule && $quantity) {
            $result = apiCall('POST', 'bookings.php', $token,
                ['user_id' => $customer, 'schedule_id' => $schedule, 'quantity' => $quantity]);
        } else $result['body']['message'] = 'Select a customer, schedule and valid quantity';
    } elseif ($action === 'update' && $id) {
        $quantity = validId($_POST['quantity'] ?? null);
        $status = $_POST['booking_status'] ?? '';
        if ($quantity && in_array($status, ['confirmed', 'cancelled'], true)) {
            $result = apiCall('PUT', 'bookings.php?id=' . $id, $token,
                ['quantity' => $quantity, 'booking_status' => $status]);
        } else $result['body']['message'] = 'Invalid quantity or status';
    } elseif ($action === 'delete' && $id) {
        $result = apiCall('DELETE', 'bookings.php?id=' . $id, $token);
    }
    $_SESSION['bookings_flash'] = [
        'success' => !empty($result['body']['success']) && $result['status'] >= 200 && $result['status'] < 300,
        'message' => $result['body']['message'] ?? 'Request completed',
    ];
    header('Location: manage_bookings.php', true, 303);
    exit;
}
$flash = $_SESSION['bookings_flash'] ?? null;
unset($_SESSION['bookings_flash']);
$bookingsResult = apiCall('GET', 'bookings.php', $token);
$usersResult = apiCall('GET', 'users.php', $token);
$schedulesResult = apiCall('GET', 'schedules.php', $token);
$bookings = $bookingsResult['body']['data'] ?? [];
$users = $usersResult['body']['data'] ?? [];
$schedules = $schedulesResult['body']['data'] ?? [];
if (!is_array($bookings)) $bookings = [];
if (!is_array($users)) $users = [];
if (!is_array($schedules)) $schedules = [];
$customers = array_values(array_filter($users, fn($u) => is_array($u) && ($u['role'] ?? '') === 'customer'));
$loadError = $bookingsResult['status'] !== 200 ? ($bookingsResult['body']['message'] ?? 'Cannot load bookings') : '';
$selectionError = ($usersResult['status'] !== 200 || $schedulesResult['status'] !== 200);
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Bookings | EventTix</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;color:#18213d;font-family:Arial,sans-serif}.layout{display:flex;min-height:100vh}.sidebar{width:250px;background:white;padding:30px 18px;border-right:1px solid #e9eaf2;flex-shrink:0}.logo{font-size:23px;font-weight:800;margin:0 0 45px 14px}.logo span{color:#8758f7}.menu-label{color:#9a9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav-link{display:block;text-decoration:none;color:#65708b;padding:14px 16px;border-radius:12px;margin-bottom:7px;font-size:14px}.nav-link:hover,.nav-link.active{background:#f0eaff;color:#7144e8;font-weight:bold}.main{flex:1;padding:35px 45px;min-width:0}.topbar{display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:28px}h1{font-size:29px;margin:0 0 8px}.subtitle{color:#8b91a4;margin:0}.btn{background:#794ce9;border:0;border-radius:11px;color:white;padding:12px 18px;cursor:pointer;font-size:13px;font-weight:600}.btn:hover{background:#643bd0}.btn.secondary{background:#f0eaff;color:#7042e3}.btn.danger{background:#fff0f0;color:#d33c50}.btn.small{padding:8px 12px}.btn:disabled{opacity:.5;cursor:not-allowed}.panel{background:#fff;border-radius:20px;padding:25px;box-shadow:0 4px 20px #19254b08;overflow-x:auto}.toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}.search{padding:12px;border:1px solid #dddfea;border-radius:10px;width:300px;max-width:100%}table{width:100%;border-collapse:collapse;min-width:850px}th,td{padding:16px 12px;border-bottom:1px solid #f0f0f5;text-align:left;font-size:13px}th{color:#9499aa;font-size:12px}.status{display:inline-block;border-radius:20px;padding:7px 11px;background:#e9f8f0;color:#207b4c;text-transform:capitalize}.status.cancelled{background:#fff0f0;color:#c34455}.actions{display:flex;gap:8px}.actions form{margin:0}.alert{padding:14px 18px;border-radius:12px;margin-bottom:20px;font-size:14px}.alert.success{background:#e9f8f0;color:#207b4c}.alert.error{background:#fff0f0;color:#bc354a}.modal-backdrop{position:fixed;inset:0;background:#10162d99;display:none;align-items:center;justify-content:center;padding:20px;z-index:100}.modal-backdrop.open{display:flex}.modal{background:white;width:100%;max-width:520px;padding:28px;border-radius:20px;max-height:90vh;overflow-y:auto}.modal h2{margin-top:0}.field{margin-bottom:17px}.field label{display:block;font-size:13px;margin-bottom:8px;font-weight:600}.field input,.field select{width:100%;padding:12px;border:1px solid #dddfea;border-radius:10px;font-size:14px}.hint{font-size:12px;color:#8b91a4;line-height:1.5}.modal-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:22px}@media(max-width:750px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.menu-label{display:none}.nav-link{display:inline-block;margin:3px}.main{padding:20px}.topbar{align-items:flex-start;flex-direction:column}.toolbar{flex-direction:column;align-items:stretch}}
</style></head><body>
<div class="layout"><aside class="sidebar">
<div class="logo">✦ EVENT<span>TIX</span></div><div class="menu-label">MAIN MENU</div>
<a class="nav-link" href="admin.php">◈ Dashboard</a>
<a class="nav-link" href="manage_users.php">♙ Manage Users</a>
<a class="nav-link" href="manage_events.php">◇ Manage Events</a>
<a class="nav-link" href="manage_venues.php">▣ Manage Venues</a>
<a class="nav-link active" href="manage_bookings.php">▤ Manage Bookings</a>
<div class="menu-label">ACCOUNT</div><a class="nav-link" href="../logout.php">↪ Logout</a>
</aside><main class="main">
<div class="topbar"><div><h1>Manage Bookings</h1><p class="subtitle">View, create and manage ticket reservations.</p></div>
<button class="btn" type="button" onclick="openCreate()" <?= ($selectionError || !$customers || !$schedules) ? 'disabled' : '' ?>>+ Add Booking</button></div>
<?php if ($flash): ?><div class="alert <?= $flash['success'] ? 'success' : 'error' ?>"><?= h($flash['message']) ?></div><?php endif; ?>
<?php if ($loadError): ?><div class="alert error"><?= h($loadError) ?></div><?php endif; ?>
<?php if ($selectionError): ?><div class="alert error">Customer or schedule options could not be loaded. Check users.php and schedules.php.</div><?php endif; ?>
<section class="panel"><div class="toolbar"><strong>All Bookings (<?= count($bookings) ?>)</strong><input class="search" id="search" placeholder="Search bookings..." oninput="filterRows()" aria-label="Search bookings"></div>
<table><thead><tr><th>ID</th><th>Customer</th><th>Event</th><th>Schedule</th><th>Tickets</th><th>Total (RM)</th><th>Status</th><th>Actions</th></tr></thead><tbody id="bookingRows">
<?php foreach ($bookings as $b): if (!is_array($b)) continue; ?>
<tr><td>#<?= h($b['booking_id'] ?? '') ?></td><td><?= h($b['customer_name'] ?? '') ?></td><td><?= h($b['event_title'] ?? '') ?></td><td><?= h($b['start_time'] ?? '') ?></td><td><?= h($b['quantity'] ?? '') ?></td><td><?= h(number_format((float)($b['total_price'] ?? 0), 2)) ?></td><td><span class="status <?= ($b['booking_status'] ?? '') === 'cancelled' ? 'cancelled' : '' ?>"><?= h($b['booking_status'] ?? '') ?></span></td><td><div class="actions">
<button type="button" class="btn secondary small" onclick="openEdit(this)" data-id="<?= h($b['booking_id'] ?? '') ?>" data-quantity="<?= h($b['quantity'] ?? '') ?>" data-status="<?= h($b['booking_status'] ?? '') ?>">Edit</button>
<form method="post" onsubmit="return confirm('Delete booking #<?= h($b['booking_id'] ?? '') ?>? This cannot be undone.');"><input type="hidden" name="csrf" value="<?= h($_SESSION['bookings_csrf']) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="booking_id" value="<?= h($b['booking_id'] ?? '') ?>"><button class="btn danger small" type="submit">Delete</button></form>
</div></td></tr>
<?php endforeach; ?>
<?php if (!$bookings): ?><tr><td colspan="8">No bookings available.</td></tr><?php endif; ?>
</tbody></table></section></main></div>
<div class="modal-backdrop" id="bookingModal"><div class="modal"><h2 id="modalTitle">Add Booking</h2><form method="post" id="bookingForm">
<input type="hidden" name="csrf" value="<?= h($_SESSION['bookings_csrf']) ?>"><input type="hidden" name="action" id="formAction" value="create"><input type="hidden" name="booking_id" id="bookingId">
<div id="createFields"><div class="field"><label for="customer">Customer</label><select id="customer" name="user_id" required><option value="">Select customer</option><?php foreach ($customers as $u): ?><option value="<?= h($u['user_id'] ?? '') ?>"><?= h($u['full_name'] ?? '') ?> (#<?= h($u['user_id'] ?? '') ?>)</option><?php endforeach; ?></select></div>
<div class="field"><label for="schedule">Event Schedule</label><select id="schedule" name="schedule_id" required><option value="">Select schedule</option><?php foreach ($schedules as $s): if (!is_array($s)) continue; ?><option value="<?= h($s['schedule_id'] ?? '') ?>">#<?= h($s['schedule_id'] ?? '') ?> — <?= h($s['event_title'] ?? $s['title'] ?? ('Event #' . ($s['event_id'] ?? '?'))) ?> — <?= h($s['start_time'] ?? '') ?> (RM <?= h($s['ticket_price'] ?? '0') ?>, <?= h($s['available_tickets'] ?? '?') ?> left)</option><?php endforeach; ?></select></div></div>
<div class="field"><label for="quantity">Ticket Quantity</label><input id="quantity" name="quantity" type="number" min="1" step="1" required></div>
<div id="statusField" class="field" hidden><label for="bookingStatus">Booking Status</label><select id="bookingStatus" name="booking_status" disabled><option value="confirmed">Confirmed</option><option value="cancelled">Cancelled</option></select></div>
<p class="hint">Ticket price and stock are calculated by the backend. Cancelling a confirmed booking restores its reserved tickets.</p>
<div class="modal-actions"><button class="btn secondary" type="button" onclick="closeModal()">Cancel</button><button class="btn" type="submit">Save Booking</button></div></form></div></div>
<script>
const modal=document.getElementById('bookingModal');
function openCreate(){document.getElementById('bookingForm').reset();document.getElementById('modalTitle').textContent='Add Booking';document.getElementById('formAction').value='create';document.getElementById('bookingId').value='';document.getElementById('createFields').hidden=false;document.getElementById('customer').disabled=false;document.getElementById('schedule').disabled=false;document.getElementById('statusField').hidden=true;document.getElementById('bookingStatus').disabled=true;modal.classList.add('open')}
function openEdit(button){document.getElementById('bookingForm').reset();document.getElementById('modalTitle').textContent='Edit Booking #'+button.dataset.id;document.getElementById('formAction').value='update';document.getElementById('bookingId').value=button.dataset.id;document.getElementById('quantity').value=button.dataset.quantity;document.getElementById('createFields').hidden=true;document.getElementById('customer').disabled=true;document.getElementById('schedule').disabled=true;document.getElementById('statusField').hidden=false;document.getElementById('bookingStatus').disabled=false;document.getElementById('bookingStatus').value=button.dataset.status;modal.classList.add('open')}
function closeModal(){modal.classList.remove('open')}
modal.addEventListener('click',e=>{if(e.target===modal)closeModal()});
function filterRows(){const term=document.getElementById('search').value.toLowerCase();document.querySelectorAll('#bookingRows tr').forEach(row=>{row.style.display=row.textContent.toLowerCase().includes(term)?'':'none'})}
</script></body></html>
