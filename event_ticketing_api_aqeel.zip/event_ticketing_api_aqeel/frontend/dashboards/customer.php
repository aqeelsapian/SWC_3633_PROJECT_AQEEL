<?php
$requiredRole = 'customer';
require __DIR__ . '/../includes/auth_guard.php';
$name = htmlspecialchars((string)($_SESSION['full_name'] ?? 'Customer'), ENT_QUOTES, 'UTF-8');
$token = (string)$_SESSION['access_token'];
function customerGet(string $path, string $token): array {
    $ch = curl_init('http://localhost/event_ticketing_api/api/' . $path);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Accept: application/json'], CURLOPT_TIMEOUT => 12, CURLOPT_FOLLOWLOCATION => false]);
    $raw = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    return ['ok' => $status === 200 && is_array($data) && !empty($data['success']), 'data' => is_array($data) ? $data : [], 'error' => $error];
}
function customerEsc($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
$bookingResult = customerGet('bookings.php', $token); // Customer bookings are filtered by the API.
$bookings = $bookingResult['data']['data'] ?? [];
if (!is_array($bookings)) $bookings = [];
$confirmed = 0; $tickets = 0; $spent = 0.0;
foreach ($bookings as $booking) {
    if (($booking['booking_status'] ?? '') === 'confirmed') {
        $confirmed++;
        $tickets += (int)($booking['quantity'] ?? 0);
        $spent += (float)($booking['total_price'] ?? 0);
    }
}
$events = []; $eventsOk = true;
for ($page = 1; $page <= 15; $page++) {
    $result = customerGet('events.php?page=' . $page . '&limit=100', $token);
    if (!$result['ok']) { $eventsOk = false; break; }
    $batch = $result['data']['data'] ?? [];
    if (!is_array($batch)) { $eventsOk = false; break; }
    foreach ($batch as $event) if (($event['status'] ?? '') === 'published') $events[] = $event;
    if ($page >= (int)($result['data']['total_pages'] ?? 1)) break;
}
$recent = array_slice(array_reverse($bookings), 0, 5);
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Customer Dashboard | EventTix</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;color:#20243d;font-family:Arial,sans-serif}.layout{display:flex;min-height:100vh}.sidebar{width:250px;flex-shrink:0;background:white;border-right:1px solid #ebebf3;padding:30px 18px}.logo{font-size:23px;font-weight:800;margin:0 0 43px 14px;color:#20243d}.logo span{color:#8758f7}.label{color:#9b9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav{display:block;text-decoration:none;color:#65708b;padding:14px 16px;border-radius:12px;margin-bottom:7px;font-size:14px}.nav:hover,.nav.active{background:#f0eaff;color:#7144e8;font-weight:700}.main{flex:1;min-width:0;padding:35px 45px}.top{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:30px}.top h1{font-size:29px;margin:0 0 8px}.muted{color:#8991a4;margin:0}.profile{background:white;border-radius:14px;padding:13px 18px;font-size:13px}.profile strong{color:#7144e8}.hero{background:linear-gradient(110deg,#6741e8,#a276ff);padding:33px;border-radius:22px;color:white;margin-bottom:28px}.hero h2{font-size:25px;margin:0 0 10px}.hero p{margin:0 0 20px;color:#f1eaff}.hero a{display:inline-block;background:#fff;color:#7144e8;text-decoration:none;border-radius:10px;padding:12px 17px;font-size:13px;font-weight:700}.cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px;margin-bottom:28px}.card,.panel{background:white;border-radius:18px;padding:25px;box-shadow:0 4px 20px #19254b08}.icon{width:44px;height:44px;border-radius:12px;background:#f0eaff;color:#7549e7;display:grid;place-items:center;font-size:21px;margin-bottom:17px}.card p{color:#8991a4;font-size:13px;margin:0 0 10px}.card h3{font-size:29px;margin:0}.panel{overflow-x:auto;margin-bottom:22px}.panel h2{font-size:19px;margin:0 0 20px}.table{width:100%;border-collapse:collapse;min-width:620px}.table th,.table td{padding:15px 12px;text-align:left;border-bottom:1px solid #f0f0f5;font-size:13px}.table th{color:#9a9eae;font-size:12px}.pill{display:inline-block;background:#f0eaff;color:#7144e8;border-radius:20px;padding:7px 11px;text-transform:capitalize}.pill.confirmed{background:#e9f8f0;color:#207b4c}.pill.cancelled{background:#fff0f0;color:#c34554}.warning{background:#fff4e5;color:#9a6115;padding:12px 16px;border-radius:12px;margin-bottom:16px;font-size:13px}.empty{color:#8991a4;font-size:14px}.section-head{display:flex;align-items:center;justify-content:space-between;gap:12px}.section-head a{color:#7144e8;text-decoration:none;font-size:13px;font-weight:700}@media(max-width:1150px){.cards{grid-template-columns:repeat(2,1fr)}}@media(max-width:650px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.label{display:none}.nav{display:inline-block;margin:3px}.top{flex-direction:column;align-items:flex-start}.main{padding:18px}.cards{grid-template-columns:1fr}}
</style></head><body><div class="layout">
<aside class="sidebar"><div class="logo">✦ EVENT<span>TIX</span></div><div class="label">CUSTOMER MENU</div><a class="nav active" href="customer.php">◈ Dashboard</a><a class="nav" href="customer_events.php">◇ Browse Events</a><a class="nav" href="customer_bookings.php">▤ My Bookings</a><div class="label">ACCOUNT</div><a class="nav" href="../logout.php">↪ Logout</a></aside>
<main class="main"><header class="top"><div><h1>Customer Dashboard</h1><p class="muted">Discover events and keep track of your tickets.</p></div><div class="profile">● <?= $name ?> · <strong>Customer</strong></div></header>
<section class="hero"><h2>Welcome to EventTix ✨</h2><p>Find your next experience and manage your event tickets in one place.</p><a href="customer_events.php">Explore Events →</a></section>
<?php if (!$bookingResult['ok'] || !$eventsOk): ?><div class="warning">Some information could not be loaded from the API. Please check your login session and backend connection.</div><?php endif; ?>
<section class="cards"><div class="card"><div class="icon">▤</div><p>Total Bookings</p><h3><?= $bookingResult['ok'] ? count($bookings) : '—' ?></h3></div><div class="card"><div class="icon">✓</div><p>Confirmed Bookings</p><h3><?= $bookingResult['ok'] ? $confirmed : '—' ?></h3></div><div class="card"><div class="icon">♧</div><p>Confirmed Tickets</p><h3><?= $bookingResult['ok'] ? $tickets : '—' ?></h3></div><div class="card"><div class="icon">RM</div><p>Confirmed Booking Value</p><h3><?= $bookingResult['ok'] ? 'RM '.number_format($spent,2) : '—' ?></h3></div></section>
<section class="panel"><div class="section-head"><h2>Recent Bookings</h2><a href="customer_bookings.php">View All →</a></div><?php if (!$recent): ?><p class="empty">No bookings yet. Browse events to get started.</p><?php else: ?><table class="table"><thead><tr><th>Booking ID</th><th>Event</th><th>Date &amp; Time</th><th>Tickets</th><th>Total</th><th>Status</th></tr></thead><tbody><?php foreach ($recent as $b): $status = strtolower((string)($b['booking_status'] ?? '')); ?><tr><td>#<?= customerEsc($b['booking_id'] ?? '') ?></td><td><?= customerEsc($b['event_title'] ?? '—') ?></td><td><?= customerEsc($b['start_time'] ?? '—') ?></td><td><?= customerEsc($b['quantity'] ?? 0) ?></td><td>RM <?= number_format((float)($b['total_price'] ?? 0),2) ?></td><td><span class="pill <?= in_array($status,['confirmed','cancelled'],true) ? customerEsc($status) : '' ?>"><?= customerEsc(ucfirst($status ?: 'Unknown')) ?></span></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></section>
<section class="panel"><div class="section-head"><h2>Available Events</h2><a href="customer_events.php">Browse Events →</a></div><p class="muted"><?= $eventsOk ? count($events) . ' published event(s) available to explore.' : 'Unable to load published events.' ?></p></section>
</main></div></body></html>
