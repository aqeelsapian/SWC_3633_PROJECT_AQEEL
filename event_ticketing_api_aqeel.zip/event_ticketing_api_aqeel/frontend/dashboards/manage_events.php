<?php
$requiredRole = 'admin';
require __DIR__ . '/../includes/auth_guard.php';

$token = $_SESSION['access_token'];
$apiBase = 'http://localhost/event_ticketing_api/api/';

function eventApi(string $method, string $endpoint, string $token, ?array $body = null): array {
    $headers = ['Authorization: Bearer ' . $token, 'Accept: application/json'];
    if ($body !== null) $headers[] = 'Content-Type: application/json';
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers, CURLOPT_TIMEOUT => 12, CURLOPT_FOLLOWLOCATION => false]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    $raw = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $json = is_string($raw) ? json_decode($raw, true) : null;
    return ['status' => $status, 'body' => is_array($json) ? $json : ['message' => $error ?: 'Invalid API response']];
}
function eh($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function eventList(string $endpoint, string $token): array {
    $all = [];
    for ($page = 1; $page <= 100; $page++) {
        $separator = str_contains($endpoint, '?') ? '&' : '?';
        $result = eventApi('GET', $endpoint . $separator . 'page=' . $page . '&limit=100', $token);
        if ($result['status'] !== 200) return ['items' => $all, 'error' => $result['body']['message'] ?? 'Failed to load data'];
        $data = $result['body']['data'] ?? [];
        if (!is_array($data)) return ['items' => $all, 'error' => 'Unexpected API response'];
        $all = array_merge($all, $data);
        $totalPages = (int)($result['body']['total_pages'] ?? 1);
        if ($page >= $totalPages || count($data) === 0) break;
    }
    return ['items' => $all, 'error' => ''];
}
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$notice = ''; $noticeType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], (string)($_POST['csrf_token'] ?? ''))) {
        http_response_code(403); exit('Invalid CSRF token');
    }
    $action = $_POST['action'] ?? '';
    if (in_array($action, ['create', 'update'], true)) {
        $payload = [
            'organiser_id' => (int)($_POST['organiser_id'] ?? 0),
            'venue_id' => (int)($_POST['venue_id'] ?? 0),
            'title' => trim((string)($_POST['title'] ?? '')),
            'description' => trim((string)($_POST['description'] ?? '')),
            'category' => trim((string)($_POST['category'] ?? '')),
            'status' => (string)($_POST['status'] ?? 'draft')
        ];
        $id = filter_var($_POST['event_id'] ?? null, FILTER_VALIDATE_INT);
        if ($payload['organiser_id'] <= 0 || $payload['venue_id'] <= 0 || $payload['title'] === '' || strlen($payload['title']) > 255 || !in_array($payload['status'], ['draft','published','cancelled'], true)) {
            $result = ['status'=>400, 'body'=>['message'=>'Please complete valid event fields.']];
        } elseif ($action === 'update' && (!$id || $id <= 0)) {
            $result = ['status'=>400, 'body'=>['message'=>'Invalid event ID.']];
        } else {
            $url = $apiBase . 'events.php' . ($action === 'update' ? '?id=' . $id : '');
            $result = eventApi($action === 'create' ? 'POST' : 'PUT', $url, $token, $payload);
        }
    } elseif ($action === 'delete') {
        $id = filter_var($_POST['event_id'] ?? null, FILTER_VALIDATE_INT);
        $result = ($id && $id > 0)
            ? eventApi('DELETE', $apiBase . 'events.php?id=' . $id, $token)
            : ['status'=>400, 'body'=>['message'=>'Invalid event ID.']];
    } else {
        $result = ['status'=>400, 'body'=>['message'=>'Invalid action.']];
    }
    $noticeType = ($result['status'] >= 200 && $result['status'] < 300 && !empty($result['body']['success'])) ? 'success' : 'error';
    $notice = $result['body']['message'] ?? 'Request completed.';
    if ($result['status'] === 401) $notice = 'Session expired. Please log in again.';
}
$eventsResult = eventList($apiBase . 'events.php', $token);
$events = $eventsResult['items'];
$usersResult = eventList($apiBase . 'users.php', $token);
$organisers = array_values(array_filter($usersResult['items'], fn($u) => ($u['role'] ?? '') === 'organiser'));
$venuesResult = eventList($apiBase . 'venues.php', $token);
$venues = $venuesResult['items'];
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Manage Events | EventTix</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f6f7fc;font-family:Arial,sans-serif;color:#18213d}.layout{display:flex;min-height:100vh}.sidebar{width:250px;background:#fff;padding:30px 18px;border-right:1px solid #e9eaf2;flex-shrink:0}.logo{font-size:23px;font-weight:800;margin:0 0 45px 14px}.logo span{color:#8758f7}.menu-label{color:#9a9eae;font-size:11px;letter-spacing:2px;margin:25px 14px 12px}.nav-link{display:block;text-decoration:none;color:#65708b;padding:14px 16px;border-radius:12px;margin-bottom:7px;font-size:14px}.nav-link:hover,.nav-link.active{background:#f0eaff;color:#7144e8;font-weight:bold}.main{flex:1;padding:35px 45px;min-width:0}.topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:28px}h1{margin:0 0 8px;font-size:29px}.subtitle{color:#8b91a4;margin:0}.btn{background:#794ce9;border:0;border-radius:11px;color:#fff;padding:12px 18px;cursor:pointer;font-size:13px;font-weight:600}.btn:hover{background:#643bd0}.btn.secondary{background:#f0eaff;color:#7042e3}.btn.danger{background:#fff0f0;color:#d33c50}.btn.small{padding:8px 12px}.panel{background:#fff;border-radius:20px;padding:25px;box-shadow:0 4px 20px #19254b08;overflow-x:auto}table{width:100%;border-collapse:collapse;min-width:850px}th,td{padding:16px 12px;border-bottom:1px solid #f0f0f5;text-align:left;font-size:13px}th{color:#9499aa;font-size:12px}.pill{background:#f0eaff;color:#7042e3;padding:7px 11px;border-radius:20px;display:inline-block;text-transform:capitalize}.pill.published{background:#e9f8f0;color:#207b4c}.pill.cancelled{background:#fff0f0;color:#bc354a}.actions{display:flex;gap:8px}.alert{padding:14px 18px;border-radius:12px;margin-bottom:20px;font-size:14px}.alert.success{background:#e9f8f0;color:#207b4c}.alert.error{background:#fff0f0;color:#bc354a}.modal-backdrop{position:fixed;inset:0;background:#10162d99;display:none;align-items:center;justify-content:center;padding:20px;z-index:100}.modal-backdrop.open{display:flex}.modal{background:#fff;width:100%;max-width:560px;padding:28px;border-radius:20px;max-height:90vh;overflow-y:auto}.modal h2{margin-top:0}.field{margin-bottom:17px}.field label{display:block;font-size:13px;margin-bottom:8px;font-weight:600}.field input,.field select,.field textarea{width:100%;padding:12px;border:1px solid #dddfea;border-radius:10px;font-size:14px;font-family:inherit}.field textarea{min-height:85px;resize:vertical}.modal-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:22px}.muted{color:#8b91a4}.search{padding:11px 14px;border:1px solid #dddfea;border-radius:11px;min-width:240px}.panel-top{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:18px}.panel-top h2{margin:0;font-size:18px}@media(max-width:750px){.layout{display:block}.sidebar{width:100%;padding:15px}.logo{margin-bottom:15px}.menu-label{display:none}.nav-link{display:inline-block;margin:3px}.main{padding:20px}.topbar,.panel-top{align-items:flex-start;flex-direction:column}.search{width:100%}}
</style></head><body>
<div class="layout"><aside class="sidebar"><div class="logo">✦ EVENT<span>TIX</span></div><div class="menu-label">MAIN MENU</div>
<a class="nav-link" href="admin.php">◈ Dashboard</a><a class="nav-link" href="manage_users.php">♙ Manage Users</a><a class="nav-link active" href="manage_events.php">◇ Manage Events</a><a class="nav-link" href="manage_venues.php">▣ Manage Venues</a><a class="nav-link" href="manage_bookings.php">▤ Manage Bookings</a><div class="menu-label">ACCOUNT</div><a class="nav-link" href="../logout.php">↪ Logout</a></aside>
<main class="main"><div class="topbar"><div><h1>Manage Events</h1><p class="subtitle">Create, update and manage EventTix events.</p></div><button class="btn" type="button" onclick="openCreate()">+ Add Event</button></div>
<?php if ($notice !== ''): ?><div class="alert <?= eh($noticeType) ?>"><?= eh($notice) ?></div><?php endif; ?>
<?php foreach (['events'=>$eventsResult,'organisers'=>$usersResult,'venues'=>$venuesResult] as $key=>$response): ?><?php if ($response['error'] !== ''): ?><div class="alert error">Unable to load <?= eh($key) ?>: <?= eh($response['error']) ?></div><?php endif; ?><?php endforeach; ?>
<section class="panel"><div class="panel-top"><h2>All Events (<?= count($events) ?>)</h2><input class="search" id="search" placeholder="Search events..." oninput="filterEvents()" aria-label="Search events"></div><table id="eventsTable"><thead><tr><th>ID</th><th>Event Name</th><th>Organiser</th><th>Venue</th><th>Category</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($events as $event): ?><tr><td>#<?= eh($event['event_id'] ?? '') ?></td><td><strong><?= eh($event['title'] ?? '') ?></strong></td><td><?= eh($event['organiser_name'] ?? $event['organiser_id'] ?? '') ?></td><td><?= eh($event['venue_name'] ?? $event['venue_id'] ?? '') ?></td><td><?= eh($event['category'] ?? '') ?></td><td><span class="pill <?= eh(in_array($event['status'] ?? '', ['published','cancelled'],true) ? $event['status'] : '') ?>"><?= eh($event['status'] ?? '') ?></span></td><td><div class="actions"><button class="btn secondary small edit-btn" type="button" data-event="<?= eh(json_encode($event, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT)) ?>" onclick="openEdit(this)">Edit</button><form method="post" onsubmit="return confirm('Delete this event? Events with schedules cannot be deleted.');"><input type="hidden" name="csrf_token" value="<?= eh($_SESSION['csrf_token']) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="event_id" value="<?= eh($event['event_id'] ?? '') ?>"><button class="btn danger small" type="submit">Delete</button></form></div></td></tr><?php endforeach; ?>
<?php if (!$events): ?><tr><td colspan="7" class="muted">No events found.</td></tr><?php endif; ?></tbody></table></section></main></div>
<div class="modal-backdrop" id="eventModal"><div class="modal"><h2 id="modalTitle">Add Event</h2><form method="post" id="eventForm"><input type="hidden" name="csrf_token" value="<?= eh($_SESSION['csrf_token']) ?>"><input type="hidden" name="action" id="formAction" value="create"><input type="hidden" name="event_id" id="eventId">
<div class="field"><label for="title">Event Title</label><input id="title" name="title" maxlength="255" required></div>
<div class="field"><label for="organiserId">Organiser</label><select id="organiserId" name="organiser_id" required><option value="">Select organiser</option><?php foreach ($organisers as $organiser): ?><option value="<?= eh($organiser['user_id'] ?? '') ?>"><?= eh($organiser['full_name'] ?? '') ?> (#<?= eh($organiser['user_id'] ?? '') ?>)</option><?php endforeach; ?></select></div>
<div class="field"><label for="venueId">Venue</label><select id="venueId" name="venue_id" required><option value="">Select venue</option><?php foreach ($venues as $venue): ?><option value="<?= eh($venue['venue_id'] ?? '') ?>"><?= eh($venue['venue_name'] ?? '') ?> (#<?= eh($venue['venue_id'] ?? '') ?>)</option><?php endforeach; ?></select></div>
<div class="field"><label for="category">Category</label><input id="category" name="category" placeholder="e.g. Concert" maxlength="150"></div>
<div class="field"><label for="description">Description</label><textarea id="description" name="description" placeholder="Describe the event..."></textarea></div>
<div class="field"><label for="status">Status</label><select id="status" name="status"><option value="draft">Draft</option><option value="published">Published</option><option value="cancelled">Cancelled</option></select></div>
<div class="modal-actions"><button class="btn secondary" type="button" onclick="closeModal()">Cancel</button><button class="btn" type="submit">Save Event</button></div></form></div></div>
<script>
const modal=document.getElementById('eventModal');
function openCreate(){document.getElementById('eventForm').reset();document.getElementById('modalTitle').textContent='Add New Event';document.getElementById('formAction').value='create';document.getElementById('eventId').value='';modal.classList.add('open')}
function openEdit(btn){const ev=JSON.parse(btn.dataset.event);document.getElementById('modalTitle').textContent='Edit Event';document.getElementById('formAction').value='update';document.getElementById('eventId').value=ev.event_id;for(const key of ['title','description','category','status'])document.getElementById(key).value=ev[key]??'';document.getElementById('organiserId').value=ev.organiser_id;document.getElementById('venueId').value=ev.venue_id;modal.classList.add('open')}
function closeModal(){modal.classList.remove('open')}
modal.addEventListener('click',ev=>{if(ev.target===modal)closeModal()});
function filterEvents(){const q=document.getElementById('search').value.toLowerCase();document.querySelectorAll('#eventsTable tbody tr').forEach(row=>row.style.display=row.textContent.toLowerCase().includes(q)?'':'none')}
</script></body></html>
